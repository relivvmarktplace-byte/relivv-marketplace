import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { 
  Calendar, 
  Download, 
  Filter, 
  Receipt, 
  TrendingUp, 
  ShoppingBag,
  Package,
  XCircle,
  CheckCircle,
  Clock,
  RefreshCw
} from 'lucide-react';

const TransactionHistoryPage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [transactions, setTransactions] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all'); // all, purchases, sales
  const [statusFilter, setStatusFilter] = useState(''); // pending, held, completed, refunded, cancelled
  const [showFilters, setShowFilters] = useState(false);
  const [dateRange, setDateRange] = useState({ start: '', end: '' });

  useEffect(() => {
    fetchTransactionHistory();
    fetchInvoices();
  }, [activeTab, statusFilter, dateRange]);

  const fetchTransactionHistory = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const params = new URLSearchParams();
      
      if (activeTab === 'purchases') params.append('role', 'buyer');
      if (activeTab === 'sales') params.append('role', 'seller');
      if (statusFilter) params.append('status', statusFilter);
      if (dateRange.start) params.append('start_date', dateRange.start);
      if (dateRange.end) params.append('end_date', dateRange.end);

      const response = await fetch(
        `${process.env.REACT_APP_BACKEND_URL}/api/transaction-history?${params.toString()}`,
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        setTransactions(data);
      }
    } catch (error) {
      console.error('Failed to fetch transaction history:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchInvoices = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const params = new URLSearchParams();
      
      if (activeTab === 'purchases') params.append('transaction_type', 'buyer');
      if (activeTab === 'sales') params.append('transaction_type', 'seller');

      const response = await fetch(
        `${process.env.REACT_APP_BACKEND_URL}/api/invoices?${params.toString()}`,
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        setInvoices(data);
      }
    } catch (error) {
      console.error('Failed to fetch invoices:', error);
    }
  };

  const downloadInvoice = async (invoiceId, invoiceNumber) => {
    try {
      const token = localStorage.getItem('access_token');
      const response = await fetch(
        `${process.env.REACT_APP_BACKEND_URL}/api/invoices/${invoiceId}/download`,
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        // Open PDF in new tab
        window.open(process.env.REACT_APP_BACKEND_URL + data.pdf_url, '_blank');
      }
    } catch (error) {
      console.error('Failed to download invoice:', error);
      alert('Failed to download invoice. Please try again.');
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      case 'held':
        return <Package className="w-5 h-5 text-blue-500" />;
      case 'refunded':
        return <RefreshCw className="w-5 h-5 text-purple-500" />;
      case 'cancelled':
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return <Clock className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusText = (status) => {
    const statusMap = {
      'pending': 'Pending',
      'held': 'In Escrow',
      'completed': 'Completed',
      'refunded': 'Refunded',
      'cancelled': 'Cancelled'
    };
    return statusMap[status] || status;
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Calculate summary statistics
  const stats = {
    total: transactions.length,
    purchases: transactions.filter(t => t.user_role === 'buyer').length,
    sales: transactions.filter(t => t.user_role === 'seller').length,
    totalSpent: transactions
      .filter(t => t.user_role === 'buyer' && t.status === 'completed')
      .reduce((sum, t) => sum + t.total_amount, 0),
    totalEarned: transactions
      .filter(t => t.user_role === 'seller' && t.status === 'completed')
      .reduce((sum, t) => sum + t.amount, 0)
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading transaction history...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Receipt className="w-8 h-8 text-blue-600" />
            Transaction History & Invoices
          </h1>
          <p className="mt-2 text-gray-600">
            View all your transactions, download invoices, and track your activity
          </p>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Transactions</p>
                <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <Receipt className="w-10 h-10 text-blue-600" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Purchases</p>
                <p className="text-2xl font-bold text-gray-900">{stats.purchases}</p>
              </div>
              <ShoppingBag className="w-10 h-10 text-green-600" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Sales</p>
                <p className="text-2xl font-bold text-gray-900">{stats.sales}</p>
              </div>
              <TrendingUp className="w-10 h-10 text-purple-600" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">
                  {activeTab === 'sales' ? 'Total Earned' : 'Total Spent'}
                </p>
                <p className="text-2xl font-bold text-gray-900">
                  €{(activeTab === 'sales' ? stats.totalEarned : stats.totalSpent).toFixed(2)}
                </p>
              </div>
              <TrendingUp className="w-10 h-10 text-orange-600" />
            </div>
          </div>
        </div>

        {/* Tabs and Filters */}
        <div className="bg-white rounded-lg shadow mb-6">
          <div className="border-b border-gray-200">
            <div className="flex items-center justify-between px-6 py-4">
              <div className="flex space-x-8">
                <button
                  onClick={() => setActiveTab('all')}
                  className={`pb-2 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === 'all'
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  All Transactions
                </button>
                <button
                  onClick={() => setActiveTab('purchases')}
                  className={`pb-2 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === 'purchases'
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Purchases
                </button>
                <button
                  onClick={() => setActiveTab('sales')}
                  className={`pb-2 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === 'sales'
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Sales
                </button>
              </div>

              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <Filter className="w-4 h-4" />
                Filters
              </button>
            </div>
          </div>

          {/* Filters Panel */}
          {showFilters && (
            <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Status
                  </label>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="held">In Escrow</option>
                    <option value="completed">Completed</option>
                    <option value="refunded">Refunded</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Start Date
                  </label>
                  <input
                    type="date"
                    value={dateRange.start}
                    onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    End Date
                  </label>
                  <input
                    type="date"
                    value={dateRange.end}
                    onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Transactions List */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          {transactions.length === 0 ? (
            <div className="text-center py-12">
              <Receipt className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No transactions found</h3>
              <p className="text-gray-600">
                {activeTab === 'purchases'
                  ? "You haven't made any purchases yet."
                  : activeTab === 'sales'
                  ? "You haven't made any sales yet."
                  : "Your transaction history will appear here."}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {transactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="p-6 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4 flex-1">
                      {/* Product Image */}
                      {transaction.product_images && transaction.product_images.length > 0 && (
                        <img
                          src={transaction.product_images[0]}
                          alt={transaction.product_title}
                          className="w-20 h-20 object-cover rounded-lg"
                        />
                      )}

                      {/* Transaction Details */}
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          {getStatusIcon(transaction.status)}
                          <h3 className="text-lg font-semibold text-gray-900">
                            {transaction.product_title}
                          </h3>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-gray-600">
                          <div>
                            <span className="font-medium">Transaction ID:</span>{' '}
                            {transaction.id.substring(0, 12)}...
                          </div>
                          <div>
                            <span className="font-medium">Date:</span>{' '}
                            {formatDate(transaction.created_at)}
                          </div>
                          <div>
                            <span className="font-medium">
                              {transaction.user_role === 'buyer' ? 'Seller' : 'Buyer'}:
                            </span>{' '}
                            {transaction.user_role === 'buyer'
                              ? transaction.seller_name
                              : transaction.buyer_name}
                          </div>
                          <div>
                            <span className="font-medium">Status:</span>{' '}
                            <span className="font-semibold">
                              {getStatusText(transaction.status)}
                            </span>
                          </div>
                        </div>

                        {/* Amount Breakdown */}
                        <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
                            <div>
                              <span className="text-gray-600">Product Price:</span>
                              <span className="ml-2 font-semibold text-gray-900">
                                €{transaction.amount.toFixed(2)}
                              </span>
                            </div>
                            <div>
                              <span className="text-gray-600">Platform Fee:</span>
                              <span className="ml-2 font-semibold text-gray-900">
                                €{transaction.commission.toFixed(2)}
                              </span>
                            </div>
                            <div>
                              <span className="text-gray-600">Total:</span>
                              <span className="ml-2 font-bold text-blue-600">
                                €{transaction.total_amount.toFixed(2)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="ml-4 flex flex-col gap-2">
                      {transaction.has_invoice && (
                        <button
                          onClick={() =>
                            downloadInvoice(transaction.invoice_id, transaction.invoice_number)
                          }
                          className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
                        >
                          <Download className="w-4 h-4" />
                          Invoice
                        </button>
                      )}
                      <button
                        onClick={() => navigate(`/orders`)}
                        className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                      >
                        View Details
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TransactionHistoryPage;
