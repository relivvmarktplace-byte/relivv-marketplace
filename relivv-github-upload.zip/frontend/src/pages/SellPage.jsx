import React from 'react';
import { useNavigate } from 'react-router-dom';
import SellProductForm from '../components/SellProductForm';

const SellPage = () => {
  const navigate = useNavigate();

  const handleProductCreated = (product) => {
    console.log('Product created:', product);
    // Optionally redirect to product details or browse page
    setTimeout(() => {
      navigate('/browse');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 pt-24">
      <SellProductForm onProductCreated={handleProductCreated} />
    </div>
  );
};

export default SellPage;