import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '../components/ui/card';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const CategoriesPage = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await axios.get(`${BACKEND_URL}/api/categories`);
        setCategories(response.data);
      } catch (error) {
        console.error('Error fetching categories:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();
  }, []);

  const categoryIcons = [
    '📱', '👕', '🏠', '⚽', '📚', 
    '🧸', '🚗', '🎨', '🎸', '📦'
  ];

  const colors = [
    'from-blue-400 to-blue-500',
    'from-purple-400 to-purple-500', 
    'from-green-400 to-green-500',
    'from-orange-400 to-orange-500',
    'from-pink-400 to-pink-500',
    'from-indigo-400 to-indigo-500',
    'from-red-400 to-red-500',
    'from-yellow-400 to-yellow-500',
    'from-teal-400 to-teal-500',
    'from-slate-400 to-slate-500'
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 via-white to-purple-50 pt-24">
        <div className="flex flex-col items-center space-y-4">
          <div className="relative">
            <div className="animate-spin rounded-full h-16 w-16 border-4 border-indigo-200"></div>
            <div className="animate-spin rounded-full h-16 w-16 border-4 border-indigo-500 border-t-transparent absolute top-0"></div>
          </div>
          <p className="text-slate-600 font-medium">Kategoriler yükleniyor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 pt-24">
      <div className="container mx-auto px-6 py-12">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-slate-800 mb-6">🏷️ Kategoriler</h1>
          <p className="text-slate-600 text-xl max-w-2xl mx-auto">
            İlgilendiğin kategoriye göz at, harika ürünler keşfet!
          </p>
        </div>

        {/* Full Width List - All Categories Vertical */}
        <div className="max-w-4xl mx-auto space-y-3">
          {categories.map((category, index) => (
            <Link 
              key={category} 
              to={`/browse?category=${encodeURIComponent(category)}`}
              className="block group cursor-pointer bg-white hover:bg-slate-50 border border-slate-200 rounded-xl p-5 transition-all duration-300 hover:shadow-lg hover:border-indigo-300"
            >
              <div className="flex items-center space-x-4">
                <div className={`w-16 h-16 bg-gradient-to-br ${colors[index % colors.length]} rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform shadow-md`}>
                  <span className="text-3xl">{categoryIcons[index % categoryIcons.length]}</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-800 group-hover:text-indigo-600 transition-colors text-xl leading-relaxed">
                    {category}
                  </h3>
                  <p className="text-slate-500 text-sm mt-1">{category.toLowerCase()} ürünlerine göz at</p>
                </div>
                <div className="text-indigo-500 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-2xl">→</span>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center mt-16">
          <Link to="/browse">
            <button className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:from-indigo-600 hover:via-purple-600 hover:to-pink-600 text-white font-semibold px-10 py-4 rounded-2xl transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 border-0">
              🔍 Tüm Ürünleri Keşfet
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CategoriesPage;