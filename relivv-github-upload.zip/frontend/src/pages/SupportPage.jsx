import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { toast } from 'sonner';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const SupportPage = () => {
  const { t } = useTranslation();
  const [tickets, setTickets] = useState([]);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [ticketDetails, setTicketDetails] = useState(null);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [replyMessage, setReplyMessage] = useState('');
  const [sending, setSending] = useState(false);

  // New ticket form
  const [newTicket, setNewTicket] = useState({
    subject: '',
    message: '',
    category: 'other',
    priority: 'medium'
  });

  useEffect(() => {
    fetchTickets();
  }, []);

  const fetchTickets = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BACKEND_URL}/api/support/tickets`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setTickets(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching tickets:', error);
      toast.error('Failed to load tickets');
      setLoading(false);
    }
  };

  const fetchTicketDetails = async (ticketId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${BACKEND_URL}/api/support/tickets/${ticketId}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setTicketDetails(response.data);
    } catch (error) {
      console.error('Error fetching ticket details:', error);
      toast.error('Failed to load ticket details');
    }
  };

  const handleSelectTicket = (ticket) => {
    setSelectedTicket(ticket);
    fetchTicketDetails(ticket.id);
    setShowCreateForm(false);
  };

  const handleCreateTicket = async (e) => {
    e.preventDefault();
    if (!newTicket.subject || !newTicket.message) {
      toast.error('Please fill in all fields');
      return;
    }

    setSending(true);
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${BACKEND_URL}/api/support/tickets`,
        newTicket,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Ticket created successfully!');
      setNewTicket({ subject: '', message: '', category: 'other', priority: 'medium' });
      setShowCreateForm(false);
      fetchTickets();
    } catch (error) {
      console.error('Error creating ticket:', error);
      toast.error('Failed to create ticket');
    } finally {
      setSending(false);
    }
  };

  const handleSendReply = async (e) => {
    e.preventDefault();
    if (!replyMessage.trim() || !selectedTicket) return;

    setSending(true);
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${BACKEND_URL}/api/support/tickets/${selectedTicket.id}/reply`,
        { message: replyMessage },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      setReplyMessage('');
      fetchTicketDetails(selectedTicket.id);
      fetchTickets();
      toast.success('Reply sent!');
    } catch (error) {
      console.error('Error sending reply:', error);
      toast.error('Failed to send reply');
    } finally {
      setSending(false);
    }
  };

  const handleCloseTicket = async () => {
    if (!selectedTicket) return;

    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `${BACKEND_URL}/api/support/tickets/${selectedTicket.id}/status`,
        { status: 'closed' },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Ticket closed');
      setSelectedTicket(null);
      setTicketDetails(null);
      fetchTickets();
    } catch (error) {
      console.error('Error closing ticket:', error);
      toast.error('Failed to close ticket');
    }
  };

  const getStatusBadge = (status) => {
    const colors = {
      open: 'bg-blue-500',
      in_progress: 'bg-yellow-500',
      resolved: 'bg-green-500',
      closed: 'bg-gray-500'
    };
    return <Badge className={`${colors[status]} text-white`}>{status.replace('_', ' ')}</Badge>;
  };

  const getPriorityBadge = (priority) => {
    const colors = {
      low: 'bg-slate-500',
      medium: 'bg-blue-500',
      high: 'bg-orange-500',
      urgent: 'bg-red-500'
    };
    return <Badge className={`${colors[priority]} text-white`}>{priority}</Badge>;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 pt-24 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-indigo-500 border-t-transparent mx-auto mb-4"></div>
          <p className="text-slate-600">Loading support tickets...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 pt-24">
      <div className="container mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-bold text-slate-800">🎫 Support Center</h1>
          <Button
            onClick={() => {
              setShowCreateForm(true);
              setSelectedTicket(null);
            }}
            className="bg-indigo-500 hover:bg-indigo-600"
          >
            ➕ New Ticket
          </Button>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Tickets List */}
          <Card className="md:col-span-1">
            <CardHeader className="border-b">
              <CardTitle className="text-xl">My Tickets</CardTitle>
            </CardHeader>
            <CardContent className="p-0 max-h-[600px] overflow-y-auto">
              {tickets.length === 0 ? (
                <div className="p-8 text-center">
                  <p className="text-slate-500">No tickets yet</p>
                  <p className="text-sm text-slate-400 mt-2">
                    Create a ticket to get help from our support team
                  </p>
                </div>
              ) : (
                <div className="divide-y">
                  {tickets.map((ticket) => (
                    <div
                      key={ticket.id}
                      onClick={() => handleSelectTicket(ticket)}
                      className={`p-4 cursor-pointer hover:bg-slate-50 transition-colors ${
                        selectedTicket?.id === ticket.id ? 'bg-indigo-50 border-l-4 border-indigo-500' : ''
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-semibold text-slate-800 text-sm truncate flex-1">
                          {ticket.subject}
                        </h4>
                        {getStatusBadge(ticket.status)}
                      </div>
                      <p className="text-xs text-slate-600 truncate mb-2">{ticket.message}</p>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-400">
                          {new Date(ticket.created_at).toLocaleDateString()}
                        </span>
                        {getPriorityBadge(ticket.priority)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Ticket Details or Create Form */}
          <Card className="md:col-span-2 flex flex-col">
            {showCreateForm ? (
              <>
                <CardHeader className="border-b">
                  <CardTitle className="text-xl">Create New Ticket</CardTitle>
                </CardHeader>
                <CardContent className="flex-1 p-6">
                  <form onSubmit={handleCreateTicket} className="space-y-4">
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        Subject *
                      </label>
                      <Input
                        value={newTicket.subject}
                        onChange={(e) => setNewTicket({ ...newTicket, subject: e.target.value })}
                        placeholder="Brief description of your issue"
                        required
                        maxLength={200}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        Category
                      </label>
                      <select
                        value={newTicket.category}
                        onChange={(e) => setNewTicket({ ...newTicket, category: e.target.value })}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2"
                      >
                        <option value="account">Account</option>
                        <option value="payment">Payment</option>
                        <option value="product">Product</option>
                        <option value="technical">Technical</option>
                        <option value="other">Other</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        Priority
                      </label>
                      <select
                        value={newTicket.priority}
                        onChange={(e) => setNewTicket({ ...newTicket, priority: e.target.value })}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2"
                      >
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                        <option value="urgent">Urgent</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        Message *
                      </label>
                      <textarea
                        value={newTicket.message}
                        onChange={(e) => setNewTicket({ ...newTicket, message: e.target.value })}
                        placeholder="Describe your issue in detail..."
                        required
                        rows={8}
                        maxLength={2000}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2"
                      />
                      <p className="text-xs text-slate-500 mt-1">
                        {newTicket.message.length}/2000 characters
                      </p>
                    </div>

                    <div className="flex space-x-3">
                      <Button
                        type="submit"
                        disabled={sending}
                        className="flex-1 bg-indigo-500 hover:bg-indigo-600"
                      >
                        {sending ? '⏳ Creating...' : '📤 Create Ticket'}
                      </Button>
                      <Button
                        type="button"
                        onClick={() => setShowCreateForm(false)}
                        variant="outline"
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </>
            ) : selectedTicket && ticketDetails ? (
              <>
                <CardHeader className="border-b">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-xl mb-2">{ticketDetails.ticket.subject}</CardTitle>
                      <div className="flex items-center space-x-2">
                        {getStatusBadge(ticketDetails.ticket.status)}
                        {getPriorityBadge(ticketDetails.ticket.priority)}
                        <Badge variant="outline" className="text-xs">
                          {ticketDetails.ticket.category}
                        </Badge>
                      </div>
                    </div>
                    {ticketDetails.ticket.status !== 'closed' && (
                      <Button
                        onClick={handleCloseTicket}
                        variant="outline"
                        size="sm"
                        className="text-red-600 border-red-600 hover:bg-red-50"
                      >
                        Close Ticket
                      </Button>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="flex-1 overflow-y-auto p-6 space-y-4 max-h-[500px]">
                  {/* Original Message */}
                  <div className="bg-slate-100 rounded-lg p-4">
                    <p className="text-sm text-slate-700">{ticketDetails.ticket.message}</p>
                    <p className="text-xs text-slate-500 mt-2">
                      {new Date(ticketDetails.ticket.created_at).toLocaleString()}
                    </p>
                  </div>

                  {/* Replies */}
                  {ticketDetails.replies.map((reply) => (
                    <div
                      key={reply.id}
                      className={`rounded-lg p-4 ${
                        reply.is_staff ? 'bg-indigo-50 border-l-4 border-indigo-500' : 'bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center space-x-2 mb-2">
                        {reply.is_staff && (
                          <Badge className="bg-indigo-500 text-white">Support Team</Badge>
                        )}
                        <p className="text-xs text-slate-500">
                          {new Date(reply.created_at).toLocaleString()}
                        </p>
                      </div>
                      <p className="text-sm text-slate-700">{reply.message}</p>
                    </div>
                  ))}
                </CardContent>

                {ticketDetails.ticket.status !== 'closed' && (
                  <div className="border-t p-4">
                    <form onSubmit={handleSendReply} className="flex space-x-2">
                      <Input
                        value={replyMessage}
                        onChange={(e) => setReplyMessage(e.target.value)}
                        placeholder="Type your reply..."
                        className="flex-1"
                        disabled={sending}
                      />
                      <Button
                        type="submit"
                        disabled={!replyMessage.trim() || sending}
                        className="bg-indigo-500 hover:bg-indigo-600"
                      >
                        {sending ? '⏳' : '📤'} Reply
                      </Button>
                    </form>
                  </div>
                )}
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-6xl mb-4">🎫</div>
                  <p className="text-slate-600 text-lg">Select a ticket or create a new one</p>
                  <p className="text-sm text-slate-400 mt-2">
                    Our support team is here to help you
                  </p>
                </div>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SupportPage;
