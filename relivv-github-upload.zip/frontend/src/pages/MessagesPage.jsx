import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { toast } from 'sonner';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const MessagesPage = () => {
  const { t } = useTranslation();
  const [conversations, setConversations] = useState([]);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [otherUserTyping, setOtherUserTyping] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState([]);
  
  const messagesEndRef = useRef(null);
  const pollingInterval = useRef(null);
  const typingTimeout = useRef(null);
  const fileInputRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    fetchConversations();

    // Poll for new messages every 3 seconds
    pollingInterval.current = setInterval(() => {
      if (selectedConversation) {
        fetchMessages(selectedConversation.id, true);
      }
      fetchConversations(true);
    }, 3000);

    return () => {
      if (pollingInterval.current) {
        clearInterval(pollingInterval.current);
      }
    };
  }, [selectedConversation]);

  const fetchConversations = async (silent = false) => {
    try {
      if (!silent) setLoading(true);
      const token = localStorage.getItem('access_token');
      const response = await axios.get(`${BACKEND_URL}/api/messages/conversations`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setConversations(response.data);
    } catch (error) {
      if (!silent) {
        console.error('Error fetching conversations:', error);
        toast.error(t('messages.loadFailed', { defaultValue: 'Failed to load conversations' }));
      }
    } finally {
      if (!silent) setLoading(false);
    }
  };

  const fetchMessages = async (conversationId, silent = false) => {
    try {
      const token = localStorage.getItem('access_token');
      const response = await axios.get(
        `${BACKEND_URL}/api/conversations/${conversationId}/messages`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setMessages(response.data);
      
      // Check if other user is typing
      const conversation = conversations.find(c => c.id === conversationId);
      if (conversation) {
        const currentUserId = localStorage.getItem('user_id');
        const isBuyer = conversation.buyer_id === currentUserId;
        const otherTyping = isBuyer ? conversation.seller_typing : conversation.buyer_typing;
        setOtherUserTyping(otherTyping || false);
      }
    } catch (error) {
      if (!silent) {
        console.error('Error fetching messages:', error);
        toast.error(t('messages.loadFailed'));
      }
    }
  };

  const handleTyping = () => {
    if (!selectedConversation) return;
    
    // Set typing status to true
    if (!isTyping) {
      setIsTyping(true);
      updateTypingStatus(selectedConversation.id, true);
    }
    
    // Clear existing timeout
    if (typingTimeout.current) {
      clearTimeout(typingTimeout.current);
    }
    
    // Set timeout to clear typing status
    typingTimeout.current = setTimeout(() => {
      setIsTyping(false);
      updateTypingStatus(selectedConversation.id, false);
    }, 2000);
  };

  const updateTypingStatus = async (conversationId, typing) => {
    try {
      const token = localStorage.getItem('access_token');
      await axios.put(
        `${BACKEND_URL}/api/conversations/${conversationId}/typing`,
        { is_typing: typing },
        { headers: { Authorization: `Bearer ${token}` } }
      );
    } catch (error) {
      console.error('Error updating typing status:', error);
    }
  };

  const handleFileSelect = (event) => {
    const files = Array.from(event.target.files);
    if (files.length > 0) {
      setSelectedFiles(files);
    }
  };

  const uploadFile = async (file) => {
    const formData = new FormData();
    formData.append('file', file);

    try {
      const token = localStorage.getItem('access_token');
      const response = await axios.post(
        `${BACKEND_URL}/api/upload-file`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data'
          }
        }
      );
      return response.data;
    } catch (error) {
      console.error('Error uploading file:', error);
      toast.error('Failed to upload file');
      return null;
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    
    if (!newMessage.trim() && selectedFiles.length === 0) return;
    if (!selectedConversation) return;

    setSending(true);
    
    try {
      // Upload files if any
      let attachments = [];
      if (selectedFiles.length > 0) {
        setUploadingFile(true);
        for (const file of selectedFiles) {
          const uploadResult = await uploadFile(file);
          if (uploadResult) {
            attachments.push(uploadResult);
          }
        }
        setUploadingFile(false);
      }

      const token = localStorage.getItem('access_token');
      await axios.post(
        `${BACKEND_URL}/api/conversations/${selectedConversation.id}/messages`,
        {
          content: newMessage,
          attachments: attachments
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setNewMessage('');
      setSelectedFiles([]);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      
      // Clear typing status
      setIsTyping(false);
      updateTypingStatus(selectedConversation.id, false);
      
      // Fetch messages immediately
      fetchMessages(selectedConversation.id);
      fetchConversations(true);
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error(t('messages.sendFailed', { defaultValue: 'Failed to send message' }));
    } finally {
      setSending(false);
    }
  };

  const selectConversation = (conversation) => {
    setSelectedConversation(conversation);
    setMessages([]);
    fetchMessages(conversation.id);
  };

  const formatTime = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const renderAttachment = (attachment) => {
    if (attachment.type === 'image') {
      return (
        <div className="mt-2">
          <img
            src={`${BACKEND_URL}${attachment.url}`}
            alt={attachment.name}
            className="max-w-sm rounded-lg shadow-md cursor-pointer hover:opacity-90"
            onClick={() => window.open(`${BACKEND_URL}${attachment.url}`, '_blank')}
          />
        </div>
      );
    } else {
      return (
        <div className="mt-2 p-3 bg-slate-100 rounded-lg flex items-center space-x-3">
          <span className="text-2xl">📄</span>
          <div className="flex-1">
            <p className="font-medium text-slate-800">{attachment.name}</p>
            <p className="text-xs text-slate-500">{(attachment.size / 1024).toFixed(2)} KB</p>
          </div>
          <a
            href={`${BACKEND_URL}${attachment.url}`}
            download={attachment.name}
            className="text-indigo-600 hover:text-indigo-700 font-medium"
          >
            Download
          </a>
        </div>
      );
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 pt-24 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-indigo-500 border-t-transparent mx-auto mb-4"></div>
          <p className="text-slate-600">Loading messages...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 pt-24">
      <div className="container mx-auto px-6 py-8 h-[calc(100vh-120px)]">
        <div className="flex h-full space-x-6">
          {/* Conversations List */}
          <div className="w-1/3">
            <Card className="h-full border-0 shadow-xl flex flex-col">
              <div className="p-6 border-b border-slate-200">
                <h2 className="text-2xl font-bold text-slate-800">💬 {t('messages.title', { defaultValue: 'Messages' })}</h2>
              </div>
              <div className="flex-1 overflow-y-auto">
                {conversations.length === 0 ? (
                  <div className="p-12 text-center">
                    <div className="text-6xl mb-4">💬</div>
                    <p className="text-slate-600">{t('messages.noConversations', { defaultValue: 'No conversations yet' })}</p>
                  </div>
                ) : (
                  conversations.map((conv) => (
                    <div
                      key={conv.id}
                      onClick={() => selectConversation(conv)}
                      className={`p-4 border-b border-slate-100 cursor-pointer hover:bg-slate-50 transition-colors ${
                        selectedConversation?.id === conv.id ? 'bg-indigo-50 border-l-4 border-indigo-500' : ''
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold text-slate-800 line-clamp-1">{conv.product_title}</h3>
                        {(conv.buyer_unread_count > 0 || conv.seller_unread_count > 0) && (
                          <Badge className="bg-indigo-500 text-white">{conv.buyer_unread_count + conv.seller_unread_count}</Badge>
                        )}
                      </div>
                      <p className="text-sm text-slate-600 line-clamp-1">{conv.last_message || 'No messages yet'}</p>
                      <p className="text-xs text-slate-400 mt-1">{conv.last_message_at ? formatTime(conv.last_message_at) : ''}</p>
                    </div>
                  ))
                )}
              </div>
            </Card>
          </div>

          {/* Messages View */}
          <div className="w-2/3">
            <Card className="h-full border-0 shadow-xl flex flex-col">
              {selectedConversation ? (
                <>
                  {/* Header */}
                  <div className="p-6 border-b border-slate-200">
                    <h3 className="text-xl font-bold text-slate-800">{selectedConversation.product_title}</h3>
                    <p className="text-sm text-slate-600">{selectedConversation.other_user_name}</p>
                  </div>

                  {/* Messages */}
                  <div className="flex-1 overflow-y-auto p-6 space-y-4">
                    {messages.map((msg) => {
                      const isOwn = msg.sender_id === localStorage.getItem('user_id');
                      return (
                        <div key={msg.id} className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-[70%] ${isOwn ? 'bg-indigo-500 text-white' : 'bg-white text-slate-800'} rounded-2xl px-4 py-3 shadow-md`}>
                            {msg.message && <p className="break-words">{msg.message}</p>}
                            {msg.attachments && msg.attachments.map((att, idx) => (
                              <div key={idx}>{renderAttachment(att)}</div>
                            ))}
                            <div className="flex items-center justify-between mt-2 space-x-2">
                              <span className={`text-xs ${isOwn ? 'text-indigo-200' : 'text-slate-400'}`}>
                                {formatTime(msg.created_at)}
                              </span>
                              {isOwn && msg.read && (
                                <span className="text-xs text-indigo-200">✓✓</span>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                    
                    {/* Typing Indicator */}
                    {otherUserTyping && (
                      <div className="flex justify-start">
                        <div className="bg-white rounded-2xl px-4 py-3 shadow-md">
                          <div className="flex space-x-1">
                            <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                            <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                            <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <div ref={messagesEndRef} />
                  </div>

                  {/* Selected Files Preview */}
                  {selectedFiles.length > 0 && (
                    <div className="px-6 py-3 border-t border-slate-200 bg-slate-50">
                      <div className="flex flex-wrap gap-2">
                        {selectedFiles.map((file, idx) => (
                          <div key={idx} className="bg-white px-3 py-2 rounded-lg shadow-sm flex items-center space-x-2">
                            <span className="text-sm">📎 {file.name}</span>
                            <button
                              onClick={() => setSelectedFiles(selectedFiles.filter((_, i) => i !== idx))}
                              className="text-red-500 hover:text-red-600"
                            >
                              ×
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Input */}
                  <div className="p-6 border-t border-slate-200">
                    <form onSubmit={handleSendMessage} className="flex space-x-3">
                      <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleFileSelect}
                        className="hidden"
                        multiple
                        accept="image/*,.pdf,.doc,.docx"
                      />
                      <Button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        variant="outline"
                        className="px-4"
                        disabled={uploadingFile}
                      >
                        📎
                      </Button>
                      <Input
                        value={newMessage}
                        onChange={(e) => {
                          setNewMessage(e.target.value);
                          handleTyping();
                        }}
                        placeholder={t('messages.typePlaceholder', { defaultValue: 'Type your message...' })}
                        className="flex-1 rounded-xl"
                        disabled={sending || uploadingFile}
                      />
                      <Button
                        type="submit"
                        disabled={sending || uploadingFile || (!newMessage.trim() && selectedFiles.length === 0)}
                        className="bg-indigo-500 hover:bg-indigo-600 px-6"
                      >
                        {uploadingFile ? '⏳' : sending ? '⏳' : '📤'}
                      </Button>
                    </form>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-6xl mb-4">💬</div>
                    <p className="text-slate-600">{t('messages.selectConversation', { defaultValue: 'Select a conversation to start messaging' })}</p>
                  </div>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessagesPage;
