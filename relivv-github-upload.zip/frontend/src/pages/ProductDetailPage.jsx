import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import axios from 'axios';
import { toast } from 'sonner';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import ProductMap from '../components/ProductMap';
import SellerRating from '../components/SellerRating';
import { AddToCartButton } from '../components/ShoppingCart';
import StarRating, { RatingDisplay } from '../components/StarRating';
import RecommendedProducts from '../components/RecommendedProducts';

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const ProductDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [seller, setSeller] = useState(null);
  const [sellerProducts, setSellerProducts] = useState([]);
  
  // Review states
  const [reviews, setReviews] = useState([]);
  const [productRating, setProductRating] = useState({ average_rating: 0, total_reviews: 0 });
  const [newReview, setNewReview] = useState({ rating: 0, comment: '' });
  const [submittingReview, setSubmittingReview] = useState(false);
  const [canReview, setCanReview] = useState(false);

  useEffect(() => {
    fetchProductDetails();
    fetchReviews();
    fetchProductRating();
    checkIfCanReview();
  }, [id]);

  const fetchProductDetails = async () => {
    try {
      setLoading(true);
      
      // Fetch product
      const productResponse = await axios.get(`${API}/products/${id}`);
      const productData = productResponse.data;
      setProduct(productData);

      // Fetch seller info
      const sellerResponse = await axios.get(`${API}/users/${productData.seller_id}/profile`);
      setSeller(sellerResponse.data);

      // Fetch seller's other products
      const sellerProductsResponse = await axios.get(`${API}/users/${productData.seller_id}/products?limit=4`);
      setSellerProducts(sellerProductsResponse.data.filter(p => p.id !== id));

    } catch (error) {
      console.error('Error fetching product:', error);
      toast.error(t('product.notFound', { defaultValue: 'Product not found' }));
      navigate('/browse');
    } finally {
      setLoading(false);
    }
  };

  const handleBuyNow = async () => {
    if (!product) return;

    try {
      // Create checkout session
      const response = await axios.post(`${API}/payment/create-checkout`, {
        product_id: product.id
      });

      // Redirect to Stripe checkout
      window.location.href = response.data.checkout_url;
    } catch (error) {
      console.error('Error creating checkout:', error);
      toast.error(t('product.checkoutError', { defaultValue: 'Failed to start checkout. Please try again.' }));
    }
  };

  const handleContactSeller = async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      toast.error('Please login to contact the seller');
      return;
    }

    try {
      // Create or get conversation
      const response = await axios.post(
        `${API}/conversations`,
        {
          product_id: product.id,
          recipient_id: product.seller_id,
          initial_message: `Hi, I'm interested in ${product.title}`
        },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      
      toast.success('Conversation started!');
      // Navigate to messages
      navigate(`/messages`);
    } catch (error) {
      console.error('Error starting conversation:', error);
      if (error.response?.status === 401) {
        toast.error('Please login to contact the seller');
      } else {
        toast.error('Failed to start conversation');
      }
    }
  };

  const nextImage = () => {
    if (product && product.images.length > 1) {
      setCurrentImageIndex((prev) => (prev + 1) % product.images.length);
    }
  };

  const prevImage = () => {
    if (product && product.images.length > 1) {
      setCurrentImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length);
    }
  };

  // Review functions
  const fetchReviews = async () => {
    try {
      const response = await axios.get(`${API}/products/${id}/reviews`);
      setReviews(response.data);
    } catch (error) {
      console.error('Error fetching reviews:', error);
    }
  };

  const fetchProductRating = async () => {
    try {
      const response = await axios.get(`${API}/products/${id}/rating`);
      setProductRating(response.data);
    } catch (error) {
      console.error('Error fetching rating:', error);
    }
  };

  const checkIfCanReview = async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      setCanReview(false);
      return;
    }

    try {
      // Check if user has purchased this product (we'll validate on backend)
      setCanReview(true); // We'll let backend handle the actual validation
    } catch (error) {
      setCanReview(false);
    }
  };

  const handleSubmitReview = async (e) => {
    e.preventDefault();
    
    if (newReview.rating === 0) {
      toast.error('Please select a rating');
      return;
    }

    const token = localStorage.getItem('token');
    if (!token) {
      toast.error('Please login to submit a review');
      return;
    }

    setSubmittingReview(true);
    try {
      await axios.post(
        `${API}/products/${id}/reviews`,
        {
          rating: newReview.rating,
          comment: newReview.comment || null
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      toast.success('Review submitted successfully!');
      setNewReview({ rating: 0, comment: '' });
      fetchReviews();
      fetchProductRating();
      setCanReview(false); // User can only review once
    } catch (error) {
      console.error('Error submitting review:', error);
      if (error.response?.status === 403) {
        toast.error('You can only review products you have purchased');
      } else if (error.response?.status === 400) {
        toast.error(error.response.data.detail || 'You have already reviewed this product');
      } else {
        toast.error('Failed to submit review');
      }
    } finally {
      setSubmittingReview(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-indigo-50 pt-24">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-indigo-500 border-t-transparent mx-auto mb-4"></div>
          <p className="text-slate-600">{t('common.loading')}</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return null;
  }

  const conditionLabels = {
    new: '✨ New',
    like_new: '💎 Like New',
    good: '👍 Good',
    fair: '👌 Fair',
    poor: '⚠️ Poor'
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 pt-24 pb-12">
      <div className="container mx-auto px-6 max-w-7xl">
        {/* Back Button */}
        <Button
          onClick={() => navigate(-1)}
          variant="outline"
          className="mb-6 rounded-xl"
        >
          ← {t('common.back', { defaultValue: 'Back' })}
        </Button>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Column - Images */}
          <div>
            <Card className="border-0 shadow-xl overflow-hidden">
              <CardContent className="p-0">
                {/* Main Image */}
                <div className="relative aspect-square bg-slate-100">
                  <img
                    src={product.images[currentImageIndex]}
                    alt={product.title}
                    className="w-full h-full object-cover"
                  />
                  
                  {/* Navigation Arrows */}
                  {product.images.length > 1 && (
                    <>
                      <button
                        onClick={prevImage}
                        className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white rounded-full w-12 h-12 flex items-center justify-center shadow-lg transition-all"
                      >
                        ←
                      </button>
                      <button
                        onClick={nextImage}
                        className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white rounded-full w-12 h-12 flex items-center justify-center shadow-lg transition-all"
                      >
                        →
                      </button>
                    </>
                  )}

                  {/* Image Counter */}
                  {product.images.length > 1 && (
                    <div className="absolute bottom-4 right-4 bg-black/70 text-white px-3 py-1 rounded-full text-sm">
                      {currentImageIndex + 1} / {product.images.length}
                    </div>
                  )}
                </div>

                {/* Thumbnail Gallery */}
                {product.images.length > 1 && (
                  <div className="grid grid-cols-5 gap-2 p-4 bg-white">
                    {product.images.map((image, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentImageIndex(index)}
                        className={`aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                          index === currentImageIndex
                            ? 'border-indigo-500 scale-105'
                            : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <img
                          src={image}
                          alt={`${product.title} ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Location Map */}
            {product.location_id && (
              <Card className="border-0 shadow-xl mt-6">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-slate-800 mb-4">
                    📍 {t('product.location', { defaultValue: 'Item Location' })}
                  </h3>
                  <ProductMap locationId={product.location_id} />
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Column - Details */}
          <div className="space-y-6">
            {/* Product Info Card */}
            <Card className="border-0 shadow-xl">
              <CardContent className="p-6">
                <div className="mb-4">
                  <span className="inline-block px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm font-medium mb-3">
                    {product.category}
                  </span>
                  <h1 className="text-3xl font-bold text-slate-800 mb-2">{product.title}</h1>
                  <div className="flex items-center space-x-2 mb-4">
                    <span className="text-4xl font-bold text-emerald-600">€{product.price}</span>
                    <span className="px-2 py-1 bg-slate-100 text-slate-600 rounded text-sm">
                      {conditionLabels[product.condition] || product.condition}
                    </span>
                  </div>
                </div>

                {/* Description */}
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-slate-800 mb-2">
                    {t('product.description', { defaultValue: 'Description' })}
                  </h3>
                  <p className="text-slate-600 whitespace-pre-line leading-relaxed">
                    {product.description}
                  </p>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <Button
                    onClick={handleBuyNow}
                    disabled={product.is_sold}
                    className="flex-1 bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white rounded-xl h-14 text-lg font-semibold shadow-lg"
                  >
                    {product.is_sold ? (
                      <>❌ {t('product.sold', { defaultValue: 'Sold Out' })}</>
                    ) : (
                      <>🛒 {t('product.buyNow', { defaultValue: 'Buy Now' })}</>
                    )}
                  </Button>
                  <AddToCartButton productId={product.id} />
                </div>

                <Button
                  onClick={handleContactSeller}
                  variant="outline"
                  className="w-full mt-3 rounded-xl h-12"
                >
                  💬 {t('product.contactSeller', { defaultValue: 'Contact Seller' })}
                </Button>
              </CardContent>
            </Card>

            {/* Seller Info Card */}
            {seller && (
              <Card className="border-0 shadow-xl">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-slate-800 mb-4">
                    👤 {t('product.seller', { defaultValue: 'Seller Information' })}
                  </h3>
                  
                  <div className="flex items-start space-x-4 mb-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-indigo-400 to-purple-400 rounded-full flex items-center justify-center text-white text-2xl font-bold flex-shrink-0">
                      {seller.name.charAt(0)}
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-semibold text-slate-800">{seller.name}</h4>
                      <SellerRating userId={seller.id} />
                      {seller.is_business_seller && (
                        <span className="inline-block mt-2 px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs font-medium">
                          ✓ {t('product.businessSeller', { defaultValue: 'Business Seller' })}
                        </span>
                      )}
                    </div>
                  </div>

                  <Button
                    onClick={() => navigate(`/seller/${seller.id}`)}
                    variant="outline"
                    className="w-full rounded-xl"
                  >
                    {t('product.viewProfile', { defaultValue: 'View Profile' })}
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Reviews Section */}
            <Card className="border-0 shadow-xl">
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold text-slate-800 mb-4">
                  ⭐ Reviews & Ratings
                </h3>

                {/* Rating Summary */}
                <div className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-xl p-6 mb-6">
                  <RatingDisplay 
                    rating={productRating.average_rating} 
                    totalReviews={productRating.total_reviews}
                    size="lg"
                  />
                </div>

                {/* Review Form (if can review) */}
                {canReview && (
                  <form onSubmit={handleSubmitReview} className="bg-slate-50 rounded-xl p-6 mb-6">
                    <h4 className="font-semibold text-slate-800 mb-4">Write a Review</h4>
                    
                    <div className="mb-4">
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Your Rating *
                      </label>
                      <StarRating
                        rating={newReview.rating}
                        interactive={true}
                        onRatingChange={(rating) => setNewReview({ ...newReview, rating })}
                        size="lg"
                      />
                    </div>

                    <div className="mb-4">
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Your Review (Optional)
                      </label>
                      <textarea
                        value={newReview.comment}
                        onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                        placeholder="Share your experience with this product..."
                        rows={4}
                        maxLength={500}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2"
                      />
                      <p className="text-xs text-slate-500 mt-1">
                        {newReview.comment.length}/500 characters
                      </p>
                    </div>

                    <Button
                      type="submit"
                      disabled={submittingReview || newReview.rating === 0}
                      className="bg-indigo-500 hover:bg-indigo-600 w-full"
                    >
                      {submittingReview ? '⏳ Submitting...' : '📤 Submit Review'}
                    </Button>
                  </form>
                )}

                {/* Reviews List */}
                <div className="space-y-4">
                  {reviews.length === 0 ? (
                    <div className="text-center py-8">
                      <p className="text-slate-500">No reviews yet</p>
                      <p className="text-sm text-slate-400 mt-2">
                        Be the first to review this product!
                      </p>
                    </div>
                  ) : (
                    reviews.map((review) => (
                      <div key={review.id} className="border border-slate-200 rounded-xl p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold">
                              {review.user_name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <h5 className="font-semibold text-slate-800">{review.user_name}</h5>
                              <p className="text-xs text-slate-500">
                                {new Date(review.created_at).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                          <StarRating rating={review.rating} size="sm" />
                        </div>
                        {review.comment && (
                          <p className="text-slate-700 text-sm leading-relaxed mt-3">
                            {review.comment}
                          </p>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Seller's Other Products */}
            {sellerProducts.length > 0 && (
              <Card className="border-0 shadow-xl">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-slate-800 mb-4">
                    🏪 {t('product.moreFromSeller', { defaultValue: 'More from this seller' })}
                  </h3>
                  
                  <div className="grid grid-cols-2 gap-3">
                    {sellerProducts.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => navigate(`/product/${item.id}`)}
                        className="cursor-pointer group"
                      >
                        <div className="aspect-square rounded-lg overflow-hidden mb-2">
                          <img
                            src={item.images[0]}
                            alt={item.title}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                          />
                        </div>
                        <h4 className="text-sm font-medium text-slate-800 line-clamp-2 group-hover:text-indigo-600">
                          {item.title}
                        </h4>
                        <p className="text-emerald-600 font-bold">€{item.price}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Similar Products */}
        <div className="container mx-auto px-6 mt-12">
          <RecommendedProducts 
            type="similar" 
            productId={id}
            title="🔍 Similar Products You May Like" 
            limit={6} 
          />
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;
