import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import WishlistButton from '../components/WishlistButton';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const WishlistPage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { t } = useTranslation();

  useEffect(() => {
    fetchWishlist();
  }, []);

  const fetchWishlist = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const response = await axios.get(`${BACKEND_URL}/api/wishlist`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setProducts(response.data.products);
    } catch (error) {
      console.error('Error fetching wishlist:', error);
      toast.error(t('wishlist.loadFailed'));
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = () => {
    // Refresh wishlist after removal
    fetchWishlist();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 pt-24 flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-4 border-indigo-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 pt-24">
      <div className="container mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">
            ❤️ {t('wishlist.title')}
          </h1>
          <p className="text-slate-600">
            {t('wishlist.itemsSaved', { count: products.length })}
          </p>
        </div>

        {products.length === 0 ? (
          <Card className="border-0 shadow-xl">
            <div className="p-12 text-center">
              <div className="text-6xl mb-4">🤍</div>
              <h3 className="text-2xl font-bold text-slate-800 mb-2">
                {t('wishlist.empty')}
              </h3>
              <p className="text-slate-600 mb-6">
                {t('wishlist.emptyDescription')}
              </p>
              <Button
                onClick={() => navigate('/browse')}
                className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600"
              >
                🔍 {t('wishlist.browseProducts')}
              </Button>
            </div>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products.map((product) => (
              <Card
                key={product.id}
                className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer overflow-hidden group"
                onClick={() => navigate(`/product/${product.id}`)}
              >
                <div className="relative">
                  <img
                    src={product.images?.[0] || '/placeholder.jpg'}
                    alt={product.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 right-2" onClick={(e) => e.stopPropagation()}>
                    <WishlistButton productId={product.id} size="lg" />
                  </div>
                  {product.is_featured && (
                    <Badge className="absolute top-2 left-2 bg-yellow-500 text-white">
                      ⭐ Featured
                    </Badge>
                  )}
                </div>
                
                <div className="p-4">
                  <h3 className="font-bold text-slate-800 mb-2 line-clamp-2">
                    {product.title}
                  </h3>
                  <p className="text-sm text-slate-600 line-clamp-2 mb-3">
                    {product.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-black text-emerald-600">
                      €{product.price}
                    </span>
                    <Badge variant="outline" className="text-xs">
                      {product.condition}
                    </Badge>
                  </div>

                  {product.pickup_address && (
                    <div className="mt-2 text-xs text-slate-500 flex items-start">
                      <span>📍</span>
                      <span className="ml-1 line-clamp-1">{product.pickup_address}</span>
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default WishlistPage;
