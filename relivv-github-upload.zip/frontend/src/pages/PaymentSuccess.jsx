import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { toast } from 'sonner';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const PaymentSuccess = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [loading, setLoading] = useState(true);
  const [paymentStatus, setPaymentStatus] = useState(null);
  const [pollCount, setPollCount] = useState(0);
  const maxPollAttempts = 5;

  const sessionId = searchParams.get('session_id');

  useEffect(() => {
    if (!sessionId) {
      toast.error(t('payment.failed'));
      navigate('/browse');
      return;
    }

    pollPaymentStatus();
  }, [sessionId]);

  const pollPaymentStatus = async (attempt = 0) => {
    if (attempt >= maxPollAttempts) {
      toast.error('Payment status check timed out. Please check your orders.');
      setLoading(false);
      return;
    }

    try {
      const response = await axios.get(
        `${BACKEND_URL}/api/payments/checkout-status/${sessionId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('access_token')}`
          }
        }
      );

      const data = response.data;
      setPaymentStatus(data);

      if (data.payment_status === 'paid') {
        toast.success(t('payment.success'));
        setLoading(false);
      } else if (data.status === 'expired' || data.payment_status === 'failed') {
        toast.error(t('payment.failed'));
        setLoading(false);
      } else {
        // Continue polling
        setPollCount(attempt + 1);
        setTimeout(() => pollPaymentStatus(attempt + 1), 2000);
      }
    } catch (error) {
      console.error('Error checking payment status:', error);
      toast.error('Error checking payment status');
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pt-24 pb-12">
        <div className="container mx-auto px-6">
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-12 text-center">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-indigo-600 mx-auto mb-6"></div>
              <h2 className="text-2xl font-bold text-slate-800 mb-2">
                {t('payment.checkingStatus')}
              </h2>
              <p className="text-slate-600">
                Please wait while we confirm your payment...
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!paymentStatus || paymentStatus.payment_status !== 'paid') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50 pt-24 pb-12">
        <div className="container mx-auto px-6">
          <Card className="max-w-2xl mx-auto border-red-200">
            <CardContent className="p-12 text-center">
              <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-4xl">❌</span>
              </div>
              <h2 className="text-2xl font-bold text-slate-800 mb-2">
                {t('payment.failed')}
              </h2>
              <p className="text-slate-600 mb-6">
                Your payment could not be processed. Please try again.
              </p>
              <Button
                onClick={() => navigate('/browse')}
                className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white font-semibold px-8 py-3 rounded-xl"
              >
                Back to Browse
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 pt-24 pb-12">
      <div className="container mx-auto px-6">
        <Card className="max-w-2xl mx-auto border-emerald-200">
          <CardHeader>
            <CardTitle className="text-center">
              <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-4xl">✅</span>
              </div>
              <h2 className="text-3xl font-bold text-slate-800">
                {t('payment.success')}
              </h2>
            </CardTitle>
          </CardHeader>
          
          <CardContent className="p-8">
            <div className="bg-white rounded-xl p-6 mb-6 border border-slate-200">
              <h3 className="font-semibold text-slate-800 mb-4">Payment Details</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600">Total Amount:</span>
                  <span className="font-black text-emerald-600 text-lg">
                    €{(paymentStatus.amount_total / 100).toFixed(2)}
                  </span>
                </div>
                <div className="text-xs text-slate-500 pl-4 space-y-1">
                  <div className="flex justify-between">
                    <span>• Product Price</span>
                    <span>Included</span>
                  </div>
                  <div className="flex justify-between">
                    <span>• Platform Fee (5%)</span>
                    <span>Included</span>
                  </div>
                </div>
                <div className="flex justify-between pt-2 border-t border-slate-100">
                  <span className="text-slate-600">Status:</span>
                  <span className="font-semibold text-emerald-600">
                    ✓ Paid
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Transaction ID:</span>
                  <span className="font-mono text-xs text-slate-600">
                    {paymentStatus.transaction_id}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-6 mb-6 border border-indigo-200">
              <h3 className="font-semibold text-slate-800 mb-2">What's Next?</h3>
              <ul className="space-y-2 text-sm text-slate-700">
                <li>✓ Payment held securely in escrow</li>
                <li>✓ Seller will contact you for delivery</li>
                <li>✓ Confirm delivery to release funds to seller</li>
                <li>✓ Funds released 3 days after delivery confirmation</li>
              </ul>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Button
                onClick={() => navigate('/orders')}
                className="w-full bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white font-semibold py-3 rounded-xl"
              >
                View My Orders
              </Button>
              <Button
                onClick={() => navigate('/browse')}
                variant="outline"
                className="w-full border-indigo-200 text-indigo-600 hover:bg-indigo-50 font-semibold py-3 rounded-xl"
              >
                Continue Shopping
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PaymentSuccess;
