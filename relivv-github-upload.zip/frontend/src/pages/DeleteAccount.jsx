import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Trash2, AlertTriangle, CheckCircle } from 'lucide-react';
import axios from 'axios';

const DeleteAccount = () => {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmText, setConfirmText] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const isNL = i18n.language === 'nl';

  const handleDeleteAccount = async (e) => {
    e.preventDefault();
    setError('');

    // Validation
    if (confirmText.toLowerCase() !== 'delete') {
      setError(isNL ? 'Type "DELETE" om te bevestigen' : 'Type "DELETE" to confirm');
      return;
    }

    if (!email || !password) {
      setError(isNL ? 'Email en wachtwoord zijn verplicht' : 'Email and password are required');
      return;
    }

    setLoading(true);

    try {
      // First login to verify credentials
      const loginResponse = await axios.post(
        `${process.env.REACT_APP_BACKEND_URL}/api/auth/login`,
        { email, password }
      );

      if (loginResponse.data.access_token) {
        // Delete account
        await axios.delete(
          `${process.env.REACT_APP_BACKEND_URL}/api/users/me`,
          {
            headers: {
              Authorization: `Bearer ${loginResponse.data.access_token}`
            }
          }
        );

        setSuccess(true);
        
        // Clear local storage
        localStorage.removeItem('access_token');
        localStorage.removeItem('user');

        // Redirect to home after 3 seconds
        setTimeout(() => {
          navigate('/');
        }, 3000);
      }
    } catch (err) {
      setError(
        isNL
          ? 'Verkeerde inloggegevens of account kan niet worden verwijderd'
          : 'Invalid credentials or account cannot be deleted'
      );
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            {isNL ? 'Account Verwijderd' : 'Account Deleted'}
          </h2>
          <p className="text-gray-600 mb-4">
            {isNL
              ? 'Uw account en alle gegevens zijn succesvol verwijderd.'
              : 'Your account and all data have been successfully deleted.'}
          </p>
          <p className="text-sm text-gray-500">
            {isNL ? 'U wordt doorgestuurd naar de homepage...' : 'Redirecting to homepage...'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Trash2 className="w-16 h-16 text-red-600 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {isNL ? 'Account Verwijderen' : 'Delete Account'}
          </h1>
          <p className="text-gray-600">
            {isNL
              ? 'Verwijder uw Relivv Marktplaats account permanent'
              : 'Permanently delete your Relivv Marktplaats account'}
          </p>
        </div>

        {/* Warning Box */}
        <div className="bg-red-50 border-l-4 border-red-500 p-6 mb-8">
          <div className="flex items-start">
            <AlertTriangle className="w-6 h-6 text-red-600 mr-3 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-lg font-semibold text-red-900 mb-2">
                {isNL ? '⚠️ Waarschuwing' : '⚠️ Warning'}
              </h3>
              <ul className="text-sm text-red-800 space-y-2 list-disc list-inside">
                {isNL ? (
                  <>
                    <li>Deze actie kan NIET ongedaan worden gemaakt</li>
                    <li>Al uw persoonlijke gegevens worden permanent verwijderd</li>
                    <li>Al uw productlijsten worden verwijderd</li>
                    <li>Uw transactiegeschiedenis wordt verwijderd</li>
                    <li>Uw berichten worden verwijderd</li>
                    <li>U kunt niet meer inloggen met dit account</li>
                  </>
                ) : (
                  <>
                    <li>This action CANNOT be undone</li>
                    <li>All your personal data will be permanently deleted</li>
                    <li>All your product listings will be removed</li>
                    <li>Your transaction history will be deleted</li>
                    <li>Your messages will be deleted</li>
                    <li>You will not be able to log in with this account</li>
                  </>
                )}
              </ul>
            </div>
          </div>
        </div>

        {/* Delete Form */}
        <div className="bg-white shadow-lg rounded-lg p-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">
            {isNL ? 'Bevestig Account Verwijdering' : 'Confirm Account Deletion'}
          </h2>

          <form onSubmit={handleDeleteAccount} className="space-y-6">
            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {isNL ? 'Email Adres' : 'Email Address'}
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder={isNL ? 'uw.email@voorbeeld.nl' : 'your.email@example.com'}
                required
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {isNL ? 'Wachtwoord' : 'Password'}
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder={isNL ? 'Uw wachtwoord' : 'Your password'}
                required
              />
            </div>

            {/* Confirmation Text */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {isNL ? 'Type "DELETE" om te bevestigen' : 'Type "DELETE" to confirm'}
              </label>
              <input
                type="text"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="DELETE"
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                {isNL
                  ? 'Type het woord DELETE (hoofdletters) om te bevestigen'
                  : 'Type the word DELETE (uppercase) to confirm'}
              </p>
            </div>

            {/* Error Message */}
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                {error}
              </div>
            )}

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                type="button"
                onClick={() => navigate('/dashboard')}
                className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                {isNL ? 'Annuleren' : 'Cancel'}
              </button>
              <button
                type="submit"
                disabled={loading || confirmText.toLowerCase() !== 'delete'}
                className="flex-1 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
              >
                {loading
                  ? isNL
                    ? 'Verwijderen...'
                    : 'Deleting...'
                  : isNL
                  ? 'Account Permanent Verwijderen'
                  : 'Permanently Delete Account'}
              </button>
            </div>
          </form>
        </div>

        {/* Additional Info */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="font-semibold text-blue-900 mb-2">
            {isNL ? 'Hulp Nodig?' : 'Need Help?'}
          </h3>
          <p className="text-sm text-blue-800 mb-3">
            {isNL
              ? 'Als u uw account wilt deactiveren in plaats van verwijderen, neem dan contact met ons op:'
              : 'If you want to deactivate your account instead of deleting it, please contact us:'}
          </p>
          <a
            href="mailto:support@relivv.nl"
            className="text-sm text-blue-600 hover:text-blue-800 font-medium"
          >
            support@relivv.nl
          </a>
        </div>
      </div>
    </div>
  );
};

export default DeleteAccount;
