import React from 'react';
import { useTranslation } from 'react-i18next';
import { Shield, Mail, Phone } from 'lucide-react';

const PrivacyPolicy = () => {
  const { t, i18n } = useTranslation();
  const isNL = i18n.language === 'nl';

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
          <div className="flex items-center gap-4 mb-6">
            <Shield className="w-12 h-12 text-blue-600" />
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                {isNL ? 'Privacybeleid' : 'Privacy Policy'}
              </h1>
              <p className="text-gray-600 mt-1">
                {isNL ? 'Laatst bijgewerkt: 22 januari 2025' : 'Last updated: January 22, 2025'}
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="bg-white rounded-lg shadow-lg p-8 space-y-8">
          {isNL ? (
            <>
              {/* Dutch Version */}
              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Inleiding</h2>
                <p className="text-gray-700 leading-relaxed">
                  Welkom bij Relivv Marktplaats ("wij", "ons", "onze"). Wij respecteren uw privacy en zetten ons in voor de bescherming van uw persoonlijke gegevens. Dit privacybeleid legt uit hoe wij uw persoonlijke informatie verzamelen, gebruiken en beschermen wanneer u onze website en mobiele applicatie gebruikt.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Gegevens die wij verzamelen</h2>
                <p className="text-gray-700 mb-3">Wij verzamelen de volgende soorten informatie:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li><strong>Accountgegevens:</strong> naam, e-mailadres, telefoonnummer, profielfoto</li>
                  <li><strong>Bedrijfsgegevens:</strong> bedrijfsnaam, BTW-nummer (voor zakelijke verkopers)</li>
                  <li><strong>Productgegevens:</strong> productbeschrijvingen, foto's, prijzen, locatie-informatie</li>
                  <li><strong>Transactiegegevens:</strong> aankoopgeschiedenis, betalingsinformatie (via Stripe)</li>
                  <li><strong>Communicatiegegevens:</strong> berichten tussen kopers en verkopers</li>
                  <li><strong>Technische gegevens:</strong> IP-adres, browsertype, apparaatinformatie, cookies</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">3. Hoe wij uw gegevens gebruiken</h2>
                <p className="text-gray-700 mb-3">Wij gebruiken uw gegevens voor:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li>Het aanmaken en beheren van uw account</li>
                  <li>Het faciliteren van transacties tussen kopers en verkopers</li>
                  <li>Het verwerken van betalingen en het verzenden van facturen</li>
                  <li>Het versturen van orderbevestigingen en leveringsupdates</li>
                  <li>Het bieden van klantenondersteuning</li>
                  <li>Het verbeteren van onze diensten en gebruikerservaring</li>
                  <li>Het naleven van wettelijke verplichtingen</li>
                  <li>Het voorkomen van fraude en misbruik</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Gegevens delen</h2>
                <p className="text-gray-700 mb-3">Wij delen uw gegevens met:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li><strong>Andere gebruikers:</strong> productinformatie, naam, beoordelingen</li>
                  <li><strong>Betalingsproviders:</strong> Stripe voor betalingsverwerking</li>
                  <li><strong>E-maildiensten:</strong> SendGrid voor e-mailnotificaties</li>
                  <li><strong>Kaartdiensten:</strong> Google Maps voor locatiediensten</li>
                  <li><strong>Wettelijke autoriteiten:</strong> wanneer wettelijk verplicht</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Gegevensbewaring</h2>
                <p className="text-gray-700 leading-relaxed">
                  Wij bewaren uw persoonlijke gegevens zolang uw account actief is of zolang nodig is voor de doeleinden waarvoor ze zijn verzameld. Na verwijdering van uw account kunnen wij bepaalde gegevens bewaren voor wettelijke, boekhoudkundige of fraudepreventiedoeleinden.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Uw rechten</h2>
                <p className="text-gray-700 mb-3">Onder de AVG heeft u de volgende rechten:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li><strong>Recht op inzage:</strong> u kunt uw persoonlijke gegevens opvragen</li>
                  <li><strong>Recht op rectificatie:</strong> u kunt onjuiste gegevens laten corrigeren</li>
                  <li><strong>Recht op verwijdering:</strong> u kunt uw gegevens laten verwijderen</li>
                  <li><strong>Recht op beperking:</strong> u kunt de verwerking beperken</li>
                  <li><strong>Recht op overdraagbaarheid:</strong> u kunt uw gegevens exporteren</li>
                  <li><strong>Recht van bezwaar:</strong> u kunt bezwaar maken tegen verwerking</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Beveiliging</h2>
                <p className="text-gray-700 leading-relaxed">
                  Wij nemen passende technische en organisatorische maatregelen om uw persoonlijke gegevens te beschermen tegen verlies, misbruik en ongeautoriseerde toegang. Dit omvat encryptie, veilige servers en regelmatige beveiligingsaudits.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Cookies</h2>
                <p className="text-gray-700 leading-relaxed">
                  Wij gebruiken cookies en vergelijkbare technologieën om uw ervaring te verbeteren, voorkeuren op te slaan en analyses uit te voeren. U kunt cookies beheren via uw browserinstellingen.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Wijzigingen in dit beleid</h2>
                <p className="text-gray-700 leading-relaxed">
                  Wij kunnen dit privacybeleid van tijd tot tijd bijwerken. Wij zullen u op de hoogte stellen van belangrijke wijzigingen via e-mail of een kennisgeving op onze website.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">10. Contact</h2>
                <p className="text-gray-700 mb-4">
                  Voor vragen over dit privacybeleid of uw persoonlijke gegevens, kunt u contact met ons opnemen:
                </p>
                <div className="bg-blue-50 p-6 rounded-lg space-y-3">
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-blue-600" />
                    <a href="mailto:privacy@relivv.nl" className="text-blue-600 hover:underline">
                      privacy@relivv.nl
                    </a>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-blue-600" />
                    <span className="text-gray-700">+31 (0) 20 123 4567</span>
                  </div>
                  <div className="text-gray-700">
                    <strong>Relivv B.V.</strong><br />
                    Amsterdam, Nederland
                  </div>
                </div>
              </section>
            </>
          ) : (
            <>
              {/* English Version */}
              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Introduction</h2>
                <p className="text-gray-700 leading-relaxed">
                  Welcome to Relivv Marktplaats ("we", "us", "our"). We respect your privacy and are committed to protecting your personal data. This privacy policy explains how we collect, use, and protect your personal information when you use our website and mobile application.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Data We Collect</h2>
                <p className="text-gray-700 mb-3">We collect the following types of information:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li><strong>Account data:</strong> name, email address, phone number, profile photo</li>
                  <li><strong>Business data:</strong> company name, VAT number (for business sellers)</li>
                  <li><strong>Product data:</strong> product descriptions, photos, prices, location information</li>
                  <li><strong>Transaction data:</strong> purchase history, payment information (via Stripe)</li>
                  <li><strong>Communication data:</strong> messages between buyers and sellers</li>
                  <li><strong>Technical data:</strong> IP address, browser type, device information, cookies</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">3. How We Use Your Data</h2>
                <p className="text-gray-700 mb-3">We use your data to:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li>Create and manage your account</li>
                  <li>Facilitate transactions between buyers and sellers</li>
                  <li>Process payments and send invoices</li>
                  <li>Send order confirmations and delivery updates</li>
                  <li>Provide customer support</li>
                  <li>Improve our services and user experience</li>
                  <li>Comply with legal obligations</li>
                  <li>Prevent fraud and abuse</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Data Sharing</h2>
                <p className="text-gray-700 mb-3">We share your data with:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li><strong>Other users:</strong> product information, name, ratings</li>
                  <li><strong>Payment providers:</strong> Stripe for payment processing</li>
                  <li><strong>Email services:</strong> SendGrid for email notifications</li>
                  <li><strong>Map services:</strong> Google Maps for location services</li>
                  <li><strong>Legal authorities:</strong> when legally required</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Data Retention</h2>
                <p className="text-gray-700 leading-relaxed">
                  We retain your personal data as long as your account is active or as needed for the purposes for which it was collected. After account deletion, we may retain certain data for legal, accounting, or fraud prevention purposes.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Your Rights</h2>
                <p className="text-gray-700 mb-3">Under GDPR, you have the following rights:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li><strong>Right to access:</strong> you can request your personal data</li>
                  <li><strong>Right to rectification:</strong> you can correct inaccurate data</li>
                  <li><strong>Right to erasure:</strong> you can request data deletion</li>
                  <li><strong>Right to restriction:</strong> you can limit processing</li>
                  <li><strong>Right to portability:</strong> you can export your data</li>
                  <li><strong>Right to object:</strong> you can object to processing</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Security</h2>
                <p className="text-gray-700 leading-relaxed">
                  We implement appropriate technical and organizational measures to protect your personal data against loss, misuse, and unauthorized access. This includes encryption, secure servers, and regular security audits.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Cookies</h2>
                <p className="text-gray-700 leading-relaxed">
                  We use cookies and similar technologies to enhance your experience, store preferences, and conduct analytics. You can manage cookies through your browser settings.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Changes to This Policy</h2>
                <p className="text-gray-700 leading-relaxed">
                  We may update this privacy policy from time to time. We will notify you of significant changes via email or a notice on our website.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">10. Contact</h2>
                <p className="text-gray-700 mb-4">
                  For questions about this privacy policy or your personal data, please contact us:
                </p>
                <div className="bg-blue-50 p-6 rounded-lg space-y-3">
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-blue-600" />
                    <a href="mailto:privacy@relivv.nl" className="text-blue-600 hover:underline">
                      privacy@relivv.nl
                    </a>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-blue-600" />
                    <span className="text-gray-700">+31 (0) 20 123 4567</span>
                  </div>
                  <div className="text-gray-700">
                    <strong>Relivv B.V.</strong><br />
                    Amsterdam, Netherlands
                  </div>
                </div>
              </section>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
