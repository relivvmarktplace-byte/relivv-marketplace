import React, { useState, useEffect } from 'react';
import { Card } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const ProductsManagement = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const limit = 12;

  useEffect(() => {
    fetchProducts();
  }, [page]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${BACKEND_URL}/api/admin/products?skip=${page * limit}&limit=${limit}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setProducts(response.data.products);
      setTotal(response.data.total);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast.error('Failed to load products');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleFeatured = async (productId, featured) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `${BACKEND_URL}/api/admin/products/${productId}/feature?featured=${featured}`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success(featured ? 'Product featured!' : 'Product unfeatured');
      fetchProducts();
    } catch (error) {
      console.error('Error toggling featured:', error);
      toast.error('Failed to update product');
    }
  };

  const handleDeleteProduct = async (productId, productTitle) => {
    if (!window.confirm(`Are you sure you want to delete "${productTitle}"?`)) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(
        `${BACKEND_URL}/api/admin/products/${productId}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success('Product deleted successfully');
      fetchProducts();
    } catch (error) {
      console.error('Error deleting product:', error);
      toast.error('Failed to delete product');
    }
  };

  const totalPages = Math.ceil(total / limit);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-800">Product Management</h1>
        <p className="text-slate-600 mt-1">Total products: {total}</p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-indigo-500 border-t-transparent"></div>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <Card key={product.id} className="border-0 shadow-lg overflow-hidden">
                <img
                  src={product.images?.[0] || '/placeholder.jpg'}
                  alt={product.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="font-semibold text-slate-800 mb-2">{product.title}</h3>
                  <p className="text-sm text-slate-600 line-clamp-2 mb-3">{product.description}</p>
                  
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xl font-bold text-emerald-600">€{product.price}</span>
                    {product.is_sold ? (
                      <Badge className="bg-red-500 text-white">Sold</Badge>
                    ) : (
                      <Badge className="bg-green-500 text-white">Available</Badge>
                    )}
                  </div>

                  <div className="text-xs text-slate-500 mb-3">
                    <p>Seller: {product.seller_name}</p>
                    <p>{product.seller_email}</p>
                  </div>

                  <div className="space-y-2">
                    <Button
                      onClick={() => handleToggleFeatured(product.id, !product.is_featured)}
                      variant="outline"
                      size="sm"
                      className={`w-full ${
                        product.is_featured
                          ? 'border-yellow-500 text-yellow-600 hover:bg-yellow-50'
                          : 'border-indigo-500 text-indigo-600 hover:bg-indigo-50'
                      }`}
                    >
                      {product.is_featured ? '⭐ Unfeature' : '⭐ Feature'}
                    </Button>
                    <Button
                      onClick={() => handleDeleteProduct(product.id, product.title)}
                      variant="outline"
                      size="sm"
                      className="w-full border-red-500 text-red-600 hover:bg-red-50"
                    >
                      🗑️ Delete
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between">
              <p className="text-sm text-slate-600">
                Page {page + 1} of {totalPages}
              </p>
              <div className="flex space-x-2">
                <Button
                  onClick={() => setPage(page - 1)}
                  disabled={page === 0}
                  variant="outline"
                  size="sm"
                >
                  ← Previous
                </Button>
                <Button
                  onClick={() => setPage(page + 1)}
                  disabled={page >= totalPages - 1}
                  variant="outline"
                  size="sm"
                >
                  Next →
                </Button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default ProductsManagement;
