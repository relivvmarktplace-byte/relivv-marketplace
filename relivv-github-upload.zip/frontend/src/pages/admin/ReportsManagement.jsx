import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const ReportsManagement = () => {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('pending');

  useEffect(() => {
    fetchReports();
  }, [filter]);

  const fetchReports = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('access_token');
      const response = await axios.get(
        `${BACKEND_URL}/api/admin/reports?status=${filter}&limit=100`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setReports(response.data.reports);
    } catch (error) {
      console.error('Error fetching reports:', error);
      toast.error('Failed to load reports');
    } finally {
      setLoading(false);
    }
  };

  const handleResolve = async (reportId, action) => {
    const notes = prompt(`Enter admin notes for this ${action} action:`);
    if (notes === null) return;

    try {
      const token = localStorage.getItem('access_token');
      await axios.put(
        `${BACKEND_URL}/api/admin/reports/${reportId}/resolve`,
        { action, notes },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success('Report resolved successfully');
      fetchReports();
    } catch (error) {
      console.error('Error resolving report:', error);
      toast.error('Failed to resolve report');
    }
  };

  const getReasonBadge = (reason) => {
    const colors = {
      spam: 'bg-yellow-500',
      fraud: 'bg-red-500',
      inappropriate: 'bg-orange-500',
      fake: 'bg-purple-500',
      harassment: 'bg-pink-500',
      other: 'bg-slate-500'
    };
    return colors[reason] || 'bg-slate-500';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-indigo-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-white">🚨 Reports Management</h1>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-48 dark:bg-slate-700 dark:text-white">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="dark:bg-slate-700">
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="reviewed">Reviewed</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
            <SelectItem value="dismissed">Dismissed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {reports.length === 0 ? (
        <Card className="dark:bg-slate-800">
          <CardContent className="p-12 text-center">
            <p className="text-slate-600 dark:text-slate-300">No {filter} reports found</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {reports.map((report) => (
            <Card key={report.id} className="dark:bg-slate-800">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <Badge className={`${getReasonBadge(report.reason)} text-white`}>
                        {report.reason}
                      </Badge>
                      <Badge variant="outline" className="dark:border-slate-600 dark:text-white">
                        {report.reported_type}
                      </Badge>
                      <span className="text-sm text-slate-500 dark:text-slate-400">
                        {new Date(report.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <h3 className="font-semibold text-slate-800 dark:text-white mb-1">
                      Reported: {report.reported_name}
                    </h3>
                    <p className="text-sm text-slate-600 dark:text-slate-300 mb-2">
                      By: {report.reporter_name}
                    </p>
                    <p className="text-slate-700 dark:text-slate-200">{report.description}</p>
                    {report.admin_notes && (
                      <div className="mt-3 p-3 bg-blue-50 dark:bg-slate-700 rounded-lg">
                        <p className="text-sm font-medium text-blue-900 dark:text-blue-300">Admin Notes:</p>
                        <p className="text-sm text-blue-800 dark:text-blue-200">{report.admin_notes}</p>
                      </div>
                    )}
                  </div>
                  {report.status === 'pending' && (
                    <div className="flex flex-col space-y-2 ml-4">
                      <Button
                        onClick={() => handleResolve(report.id, 'dismiss')}
                        variant="outline"
                        size="sm"
                        className="dark:border-slate-600 dark:text-white"
                      >
                        Dismiss
                      </Button>
                      <Button
                        onClick={() => handleResolve(report.id, 'warn')}
                        className="bg-orange-500 hover:bg-orange-600"
                        size="sm"
                      >
                        Warn
                      </Button>
                      <Button
                        onClick={() => handleResolve(report.id, 'ban')}
                        className="bg-red-500 hover:bg-red-600"
                        size="sm"
                      >
                        Ban User
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default ReportsManagement;
