import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Badge } from '../../components/ui/badge';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const TicketsManagement = () => {
  const [tickets, setTickets] = useState([]);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [ticketReplies, setTicketReplies] = useState([]);
  const [replyMessage, setReplyMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    fetchTickets();
  }, []);

  const fetchTickets = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${BACKEND_URL}/api/admin/tickets`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setTickets(response.data.tickets);
    } catch (error) {
      console.error('Error fetching tickets:', error);
      toast.error('Failed to load tickets');
    } finally {
      setLoading(false);
    }
  };

  const fetchTicketDetails = async (ticketId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${BACKEND_URL}/api/support/tickets/${ticketId}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setTicketReplies(response.data.replies || []);
    } catch (error) {
      console.error('Error fetching ticket details:', error);
    }
  };

  const handleSelectTicket = (ticket) => {
    setSelectedTicket(ticket);
    fetchTicketDetails(ticket.id);
  };

  const handleUpdateStatus = async (ticketId, newStatus) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `${BACKEND_URL}/api/admin/tickets/${ticketId}/status?status=${newStatus}`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success('Status updated');
      fetchTickets();
      if (selectedTicket?.id === ticketId) {
        setSelectedTicket({ ...selectedTicket, status: newStatus });
      }
    } catch (error) {
      console.error('Error updating status:', error);
      toast.error('Failed to update status');
    }
  };

  const handleSendReply = async (e) => {
    e.preventDefault();
    if (!replyMessage.trim()) return;

    setSending(true);
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${BACKEND_URL}/api/admin/tickets/${selectedTicket.id}/reply?message=${encodeURIComponent(replyMessage)}`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success('Reply sent');
      setReplyMessage('');
      fetchTicketDetails(selectedTicket.id);
    } catch (error) {
      console.error('Error sending reply:', error);
      toast.error('Failed to send reply');
    } finally {
      setSending(false);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      open: 'bg-blue-500',
      in_progress: 'bg-yellow-500',
      resolved: 'bg-green-500',
      closed: 'bg-gray-500'
    };
    return colors[status] || 'bg-gray-500';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-16 w-16 border-4 border-indigo-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-slate-800">Support Tickets</h1>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Tickets List */}
        <Card className="md:col-span-1">
          <CardContent className="p-0 max-h-[700px] overflow-y-auto">
            {tickets.length === 0 ? (
              <div className="p-8 text-center">
                <p className="text-slate-500">No tickets</p>
              </div>
            ) : (
              tickets.map((ticket) => (
                <div
                  key={ticket.id}
                  onClick={() => handleSelectTicket(ticket)}
                  className={`p-4 border-b cursor-pointer hover:bg-slate-50 ${
                    selectedTicket?.id === ticket.id ? 'bg-indigo-50' : ''
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-semibold text-sm">{ticket.subject}</h4>
                    <Badge className={`${getStatusColor(ticket.status)} text-white text-xs`}>
                      {ticket.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-slate-600 mb-1">{ticket.user_name}</p>
                  <p className="text-xs text-slate-500">{ticket.user_email}</p>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Ticket Details */}
        <Card className="md:col-span-2">
          {selectedTicket ? (
            <>
              <CardContent className="p-6 border-b">
                <div className="flex items-start justify-between">
                  <div>
                    <h2 className="text-xl font-bold mb-2">{selectedTicket.subject}</h2>
                    <p className="text-sm text-slate-600">From: {selectedTicket.user_name}</p>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      onClick={() => handleUpdateStatus(selectedTicket.id, 'in_progress')}
                      size="sm"
                      variant="outline"
                    >
                      In Progress
                    </Button>
                    <Button
                      onClick={() => handleUpdateStatus(selectedTicket.id, 'resolved')}
                      size="sm"
                      className="bg-green-500"
                    >
                      Resolve
                    </Button>
                  </div>
                </div>
              </CardContent>

              <CardContent className="p-6 space-y-4 max-h-[400px] overflow-y-auto">
                {/* Original Message */}
                <div className="bg-slate-100 rounded-lg p-4">
                  <p className="text-sm">{selectedTicket.message}</p>
                </div>

                {/* Replies */}
                {ticketReplies.map((reply) => (
                  <div
                    key={reply.id}
                    className={`rounded-lg p-4 ${
                      reply.is_staff ? 'bg-indigo-50 border-l-4 border-indigo-500' : 'bg-slate-50'
                    }`}
                  >
                    {reply.is_staff && (
                      <Badge className="bg-indigo-500 text-white text-xs mb-2">Support Team</Badge>
                    )}
                    <p className="text-sm">{reply.message}</p>
                  </div>
                ))}
              </CardContent>

              {selectedTicket.status !== 'closed' && (
                <CardContent className="p-6 border-t">
                  <form onSubmit={handleSendReply} className="flex space-x-2">
                    <Input
                      value={replyMessage}
                      onChange={(e) => setReplyMessage(e.target.value)}
                      placeholder="Type your reply..."
                      disabled={sending}
                    />
                    <Button type="submit" disabled={sending || !replyMessage.trim()}>
                      {sending ? '⏳' : '📤'} Send
                    </Button>
                  </form>
                </CardContent>
              )}
            </>
          ) : (
            <CardContent className="p-12 text-center">
              <div className="text-6xl mb-4">🎫</div>
              <p className="text-slate-600">Select a ticket to view details</p>
            </CardContent>
          )}
        </Card>
      </div>
    </div>
  );
};

export default TicketsManagement;
