import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const VerificationsManagement = () => {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('pending');

  useEffect(() => {
    fetchRequests();
  }, [filter]);

  const fetchRequests = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('access_token');
      const response = await axios.get(
        `${BACKEND_URL}/api/admin/verifications?status=${filter}&limit=100`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setRequests(response.data.requests);
    } catch (error) {
      console.error('Error fetching verification requests:', error);
      toast.error('Failed to load verification requests');
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (requestId, approved) => {
    const notes = prompt(`Enter notes for this ${approved ? 'approval' : 'rejection'}:`);
    if (notes === null) return;

    try {
      const token = localStorage.getItem('access_token');
      await axios.put(
        `${BACKEND_URL}/api/admin/verifications/${requestId}/approve`,
        { approved, notes },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success(`Verification ${approved ? 'approved' : 'rejected'} successfully`);
      fetchRequests();
    } catch (error) {
      console.error('Error processing verification:', error);
      toast.error('Failed to process verification');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-indigo-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-white">✓ Verification Requests</h1>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-48 dark:bg-slate-700 dark:text-white">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="dark:bg-slate-700">
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {requests.length === 0 ? (
        <Card className="dark:bg-slate-800">
          <CardContent className="p-12 text-center">
            <p className="text-slate-600 dark:text-slate-300">No {filter} verification requests found</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {requests.map((request) => (
            <Card key={request.id} className="dark:bg-slate-800">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-3">
                      <h3 className="text-xl font-bold text-slate-800 dark:text-white">
                        {request.user_name}
                      </h3>
                      <Badge variant="outline" className="dark:border-slate-600 dark:text-white">
                        {request.user_email}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400">Trust Score</p>
                        <p className="text-lg font-semibold text-slate-800 dark:text-white">
                          {request.user_trust_score || 50}/100
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400">Transactions</p>
                        <p className="text-lg font-semibold text-slate-800 dark:text-white">
                          {request.user_completed_transactions || 0}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400">Email Verified</p>
                        <p className="text-lg">
                          {request.email_verified ? '✓' : '✗'}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400">Phone Verified</p>
                        <p className="text-lg">
                          {request.phone_verified ? '✓' : '✗'}
                        </p>
                      </div>
                    </div>

                    <p className="text-sm text-slate-600 dark:text-slate-300">
                      Requested: {new Date(request.created_at).toLocaleDateString()}
                    </p>

                    {request.admin_notes && (
                      <div className="mt-3 p-3 bg-blue-50 dark:bg-slate-700 rounded-lg">
                        <p className="text-sm font-medium text-blue-900 dark:text-blue-300">Admin Notes:</p>
                        <p className="text-sm text-blue-800 dark:text-blue-200">{request.admin_notes}</p>
                      </div>
                    )}
                  </div>

                  {request.status === 'pending' && (
                    <div className="flex flex-col space-y-2 ml-4">
                      <Button
                        onClick={() => handleApprove(request.id, true)}
                        className="bg-green-500 hover:bg-green-600"
                        size="sm"
                      >
                        ✓ Approve
                      </Button>
                      <Button
                        onClick={() => handleApprove(request.id, false)}
                        variant="outline"
                        size="sm"
                        className="dark:border-slate-600 dark:text-white"
                      >
                        ✗ Reject
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default VerificationsManagement;
