import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Textarea } from '../components/ui/textarea';
import { toast } from 'sonner';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const OrdersPage = () => {
  const { t } = useTranslation();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [disputeNotes, setDisputeNotes] = useState('');
  const [selectedOrder, setSelectedOrder] = useState(null);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/transactions`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('access_token')}`
        }
      });
      setOrders(response.data || []);
    } catch (error) {
      console.error('Error fetching orders:', error);
      toast.error('Failed to load orders');
    } finally {
      setLoading(false);
    }
  };

  const confirmDelivery = async (transactionId) => {
    setActionLoading(true);
    try {
      await axios.post(
        `${BACKEND_URL}/api/transactions/${transactionId}/confirm-delivery`,
        {
          transaction_id: transactionId,
          confirmation_type: 'delivered'
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('access_token')}`
          }
        }
      );
      toast.success('Delivery confirmed! Funds will be released in 3 days.');
      fetchOrders();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to confirm delivery');
    } finally {
      setActionLoading(false);
    }
  };

  const raiseDispute = async (transactionId) => {
    setActionLoading(true);
    try {
      await axios.post(
        `${BACKEND_URL}/api/transactions/${transactionId}/confirm-delivery`,
        {
          transaction_id: transactionId,
          confirmation_type: 'dispute',
          notes: disputeNotes
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('access_token')}`
          }
        }
      );
      toast.success('Dispute raised. Our team will review and contact you.');
      setDisputeNotes('');
      setSelectedOrder(null);
      fetchOrders();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to raise dispute');
    } finally {
      setActionLoading(false);
    }
  };

  const cancelOrder = async (transactionId) => {
    if (!window.confirm('Are you sure you want to cancel this order? You will receive a full refund.')) {
      return;
    }

    setActionLoading(true);
    try {
      await axios.post(
        `${BACKEND_URL}/api/transactions/${transactionId}/cancel`,
        {},
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('access_token')}`
          }
        }
      );
      toast.success('Order cancelled. Refund will be processed within 7 business days.');
      fetchOrders();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to cancel order');
    } finally {
      setActionLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const statusColors = {
      pending: 'bg-yellow-100 text-yellow-800',
      held: 'bg-blue-100 text-blue-800',
      completed: 'bg-emerald-100 text-emerald-800',
      cancelled: 'bg-gray-100 text-gray-800',
      refunded: 'bg-purple-100 text-purple-800'
    };

    return (
      <Badge className={statusColors[status] || 'bg-slate-100 text-slate-800'}>
        {t(`orders.statuses.${status}`)}
      </Badge>
    );
  };

  const getDeliveryStatusBadge = (status) => {
    const statusColors = {
      pending: 'bg-yellow-100 text-yellow-800',
      confirmed: 'bg-emerald-100 text-emerald-800',
      disputed: 'bg-red-100 text-red-800'
    };

    return (
      <Badge className={statusColors[status] || 'bg-slate-100 text-slate-800'}>
        {t(`orders.deliveryStatuses.${status}`)}
      </Badge>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pt-24 pb-12">
        <div className="container mx-auto px-6">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-slate-200 rounded w-1/4"></div>
            <div className="h-32 bg-slate-200 rounded"></div>
            <div className="h-32 bg-slate-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pt-24 pb-12">
        <div className="container mx-auto px-6">
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-12 text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-4xl">📦</span>
              </div>
              <h2 className="text-2xl font-bold text-slate-800 mb-2">
                {t('orders.empty')}
              </h2>
              <p className="text-slate-600 mb-6">
                Start shopping to see your orders here!
              </p>
              <Button
                onClick={() => window.location.href = '/browse'}
                className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white font-semibold px-8 py-3 rounded-xl"
              >
                🔍 Browse Products
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pt-24 pb-12">
      <div className="container mx-auto px-6">
        <h1 className="text-4xl font-black text-slate-800 mb-8">
          📦 {t('orders.title')}
        </h1>

        <div className="space-y-4">
          {orders.map((order) => (
            <Card key={order.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-bold text-slate-800 mb-1">
                      Order #{order.id.substring(0, 8)}
                    </h3>
                    <p className="text-sm text-slate-600">
                      {new Date(order.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="text-right">
                    {getStatusBadge(order.status)}
                  </div>
                </div>

                <div className="bg-gradient-to-r from-slate-50 to-slate-100 rounded-lg p-4 mb-4">
                  <div className="grid grid-cols-2 gap-4 text-sm mb-3">
                    <div>
                      <span className="text-slate-600">Product Price:</span>
                      <p className="font-bold text-slate-800">€{order.amount.toFixed(2)}</p>
                    </div>
                    <div>
                      <span className="text-slate-600">Platform Fee (5%):</span>
                      <p className="font-semibold text-slate-700">€{order.commission.toFixed(2)}</p>
                    </div>
                    <div className="col-span-2">
                      <span className="text-slate-600">Total Paid:</span>
                      <p className="font-black text-emerald-600 text-xl">€{(order.total_amount || (order.amount + order.commission)).toFixed(2)}</p>
                    </div>
                  </div>
                  
                  <div className="border-t border-slate-200 pt-3 grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-slate-600">{t('orders.deliveryStatus')}:</span>
                      <div className="mt-1">
                        {getDeliveryStatusBadge(order.delivery_status)}
                      </div>
                    </div>
                    {order.auto_release_at && (
                      <div>
                        <span className="text-slate-600">Auto-release:</span>
                        <p className="font-semibold text-slate-700 text-xs">
                          {new Date(order.auto_release_at).toLocaleDateString()}
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Action Buttons */}
                {order.status === 'held' && order.delivery_status === 'pending' && (
                  <div className="flex space-x-3">
                    <Button
                      onClick={() => confirmDelivery(order.id)}
                      disabled={actionLoading}
                      className="flex-1 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-semibold py-2 rounded-xl"
                    >
                      ✓ {t('orders.confirmDelivery')}
                    </Button>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          className="flex-1 border-red-200 text-red-600 hover:bg-red-50 py-2 rounded-xl"
                          onClick={() => setSelectedOrder(order)}
                        >
                          ⚠️ {t('orders.raiseDispute')}
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>{t('orders.raiseDispute')}</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 pt-4">
                          <Textarea
                            placeholder="Please describe the issue..."
                            value={disputeNotes}
                            onChange={(e) => setDisputeNotes(e.target.value)}
                            rows={4}
                          />
                          <Button
                            onClick={() => raiseDispute(order.id)}
                            disabled={actionLoading || !disputeNotes.trim()}
                            className="w-full bg-red-500 hover:bg-red-600 text-white"
                          >
                            Submit Dispute
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                )}

                {order.status === 'pending' && (
                  <Button
                    onClick={() => cancelOrder(order.id)}
                    disabled={actionLoading}
                    variant="outline"
                    className="w-full border-red-200 text-red-600 hover:bg-red-50 py-2 rounded-xl"
                  >
                    {t('orders.cancelOrder')}
                  </Button>
                )}

                {order.status === 'held' && order.delivery_status === 'confirmed' && (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
                    <p className="text-sm text-emerald-700">
                      ✓ Delivery confirmed. Funds will be automatically released to the seller in 3 days.
                    </p>
                  </div>
                )}

                {order.status === 'completed' && (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
                    <p className="text-sm text-emerald-700">
                      ✓ Transaction completed successfully.
                    </p>
                  </div>
                )}

                {order.status === 'refunded' && (
                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                    <p className="text-sm text-purple-700">
                      ↩ Refund processed. Amount will be returned within 7 business days.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default OrdersPage;
