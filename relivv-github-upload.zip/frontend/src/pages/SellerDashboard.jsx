import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import axios from 'axios';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#3b82f6'];

const SellerDashboard = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [dashboard, setDashboard] = useState(null);
  const [performance, setPerformance] = useState([]);
  const [salesTrend, setSalesTrend] = useState([]);
  const [revenue, setRevenue] = useState(null);

  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('access_token');
      const headers = { Authorization: `Bearer ${token}` };

      const [dashboardRes, performanceRes, salesRes, revenueRes] = await Promise.all([
        axios.get(`${BACKEND_URL}/api/seller/dashboard`, { headers }),
        axios.get(`${BACKEND_URL}/api/seller/products/performance?limit=5`, { headers }),
        axios.get(`${BACKEND_URL}/api/seller/sales-trend?days=30`, { headers }),
        axios.get(`${BACKEND_URL}/api/seller/revenue`, { headers })
      ]);

      setDashboard(dashboardRes.data);
      setPerformance(performanceRes.data);
      setSalesTrend(salesRes.data);
      setRevenue(revenueRes.data);
    } catch (error) {
      console.error('Error fetching seller dashboard:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 dark:from-slate-900 dark:to-indigo-950 pt-24 flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-4 border-indigo-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 dark:from-slate-900 dark:to-indigo-950 pt-24">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-slate-800 dark:text-white">📊 Seller Dashboard</h1>
            <p className="text-slate-600 dark:text-slate-300 mt-2">Track your sales performance and insights</p>
          </div>
          <Button onClick={() => navigate('/sell')} className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600">
            ➕ List New Product
          </Button>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-0 shadow-lg dark:bg-slate-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-600 dark:text-slate-300">Total Products</span>
                <span className="text-2xl">📦</span>
              </div>
              <p className="text-3xl font-bold text-slate-800 dark:text-white">{dashboard?.total_products || 0}</p>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                {dashboard?.active_products || 0} active • {dashboard?.sold_products || 0} sold
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg dark:bg-slate-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-600 dark:text-slate-300">Total Sales</span>
                <span className="text-2xl">💰</span>
              </div>
              <p className="text-3xl font-bold text-slate-800 dark:text-white">{dashboard?.total_sales || 0}</p>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                {dashboard?.recent_sales_30d || 0} in last 30 days
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg dark:bg-slate-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-600 dark:text-slate-300">Net Revenue</span>
                <span className="text-2xl">💵</span>
              </div>
              <p className="text-3xl font-bold text-emerald-600 dark:text-emerald-400">€{dashboard?.net_revenue || 0}</p>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                Commission: €{dashboard?.total_commission || 0}
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg dark:bg-slate-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-600 dark:text-slate-300">Rating</span>
                <span className="text-2xl">⭐</span>
              </div>
              <p className="text-3xl font-bold text-slate-800 dark:text-white">{dashboard?.average_rating || 0}</p>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                {dashboard?.total_reviews || 0} reviews
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Sales Trend Chart */}
        <Card className="border-0 shadow-lg mb-8 dark:bg-slate-800">
          <CardHeader>
            <CardTitle className="dark:text-white">📈 Sales Trend (Last 30 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={salesTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" stroke="#64748b" />
                <YAxis stroke="#64748b" />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px' }} />
                <Legend />
                <Line type="monotone" dataKey="sales" stroke="#6366f1" strokeWidth={3} name="Sales Count" />
                <Line type="monotone" dataKey="net" stroke="#10b981" strokeWidth={3} name="Net Revenue (€)" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Revenue Breakdown & Top Products */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Category Revenue */}
          <Card className="border-0 shadow-lg dark:bg-slate-800">
            <CardHeader>
              <CardTitle className="dark:text-white">🎯 Revenue by Category</CardTitle>
            </CardHeader>
            <CardContent>
              {revenue?.category_breakdown?.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={revenue.category_breakdown}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ category, revenue }) => `${category}: €${revenue}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="revenue"
                    >
                      {revenue.category_breakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <p className="text-center text-slate-600 dark:text-slate-300 py-12">No sales data yet</p>
              )}
            </CardContent>
          </Card>

          {/* Top Products */}
          <Card className="border-0 shadow-lg dark:bg-slate-800">
            <CardHeader>
              <CardTitle className="dark:text-white">🔥 Top Products (By Views)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {performance.length > 0 ? (
                  performance.map((product, index) => (
                    <div key={product.product_id} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors">
                      <div className="flex items-center space-x-3 flex-1">
                        <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900 rounded-full flex items-center justify-center font-bold text-indigo-600 dark:text-indigo-300">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-slate-800 dark:text-white line-clamp-1">{product.title}</p>
                          <p className="text-sm text-slate-600 dark:text-slate-300">€{product.price}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold text-indigo-600 dark:text-indigo-400">{product.views} views</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">❤️ {product.wishlist_count}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-slate-600 dark:text-slate-300 py-12">List products to see performance</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Additional Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="border-0 shadow-lg dark:bg-slate-800">
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center text-2xl">
                  👁️
                </div>
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-300">Total Views</p>
                  <p className="text-2xl font-bold text-slate-800 dark:text-white">{dashboard?.total_views || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg dark:bg-slate-800">
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center text-2xl">
                  💬
                </div>
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-300">Active Chats</p>
                  <p className="text-2xl font-bold text-slate-800 dark:text-white">{dashboard?.active_conversations || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg dark:bg-slate-800">
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900 rounded-full flex items-center justify-center text-2xl">
                  💵
                </div>
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-300">Avg Order Value</p>
                  <p className="text-2xl font-bold text-slate-800 dark:text-white">€{revenue?.average_order_value || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SellerDashboard;
