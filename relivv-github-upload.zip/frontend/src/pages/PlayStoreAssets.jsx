import React from 'react';
import { Download, FileText, Image, Smartphone, Tablet } from 'lucide-react';

const PlayStoreAssets = () => {
  const assets = {
    texts: [
      {
        title: 'Kısa Açıklama (80 karakter)',
        content: 'Tweedehands marktplaats voor Nederland. Veilig kopen en verkopen.',
        chars: 77
      },
      {
        title: 'Tam Açıklama (4000 karakter max)',
        content: `Welkom bij Relivv Marktplaats - Nederlands betrouwbare platform voor tweedehands artikelen!

🛍️ VEILIG KOPEN EN VERKOPEN
• Beveiligde betalingen via Stripe
• Escrow systeem voor kopersbescherming  
• Geverifieerde verkopers met beoordelingen
• Trust score systeem
• Rapportage functie

📱 EENVOUDIG TE GEBRUIKEN
• Snelle productlijsten met meerdere foto's
• Duidelijke categorieën voor makkelijk zoeken
• Directe messaging tussen kopers en verkopers
• Locatie-gebaseerd zoeken met kaart
• Real-time notificaties

💰 KRACHTIGE FUNCTIES
• Producten toevoegen in enkele seconden
• Shopping cart voor meerdere items
• Favorieten lijst (wishlist)
• Complete transactiegeschiedenis
• Facturen met BTW
• Verkoperspaneel met statistieken
• Product aanbevelingen

🌍 LOKAAL & DUURZAAM
• Vind artikelen bij u in de buurt met Google Maps
• Draag bij aan circulariteit en duurzaamheid
• Steun lokale gemeenschappen
• Verminder afval door hergebruik

🔐 VEILIGHEID & VERTROUWEN
• 5% commissie voor veilige transacties
• Escrow betalingen (geld vastgehouden tot levering)
• Verkoperverificatie
• Product rapportagesysteem
• Trust badges voor betrouwbare gebruikers

📊 VOOR VERKOPERS
• Verkopersdashboard met performance metrics
• Product statistieken en views
• Gemakkelijk voorraad beheer
• Geautomatiseerde facturen
• BTW ondersteuning voor zakelijke verkopers

🌐 TWEETALIG
• Nederlands en Engels
• Automatische valuta (EUR)
• Nederlandse belastingregelgeving (21% BTW)

Download nu en begin met kopen of verkopen op Nederlands meest gebruiksvriendelijke tweedehands platform!

CATEGORIEËN:
📱 Elektronica & Technologie
👗 Mode & Kleding
🏠 Huis & Tuin
🎮 Hobby & Vrije Tijd
📚 Boeken & Media
🚗 Auto & Motor
⚽ Sport & Fitness
👶 Baby & Kind
🎨 Kunst & Antiek
🐾 Dieren & Benodigdheden

VEILIG BETALEN:
Alle betalingen via Stripe met escrow bescherming. Uw geld wordt veilig bewaard tot u de levering bevestigt.

KLANTENSERVICE:
Email: support@relivv.nl
Website: https://relivv.nl
Privacybeleid: https://relivv.nl/privacy-policy

Begin vandaag met duurzaam winkelen op Relivv Marktplaats!`,
        chars: 1819
      }
    ],
    images: [
      {
        category: 'Uygulama Simgesi',
        icon: Image,
        items: [
          { name: 'App Icon (512x512)', file: 'app-icon-512x512.png', size: '42 KB' }
        ]
      },
      {
        category: 'Özellik Grafiği',
        icon: Image,
        items: [
          { name: 'Feature Graphic (1024x500)', file: 'feature-graphic-1024x500.png', size: '143 KB' }
        ]
      },
      {
        category: 'Telefon Ekran Görüntüleri',
        icon: Smartphone,
        items: [
          { name: 'Homepage (1080x1920)', file: 'phone-1-homepage.jpg', size: '83 KB' },
          { name: 'Browse (1080x1920)', file: 'phone-2-browse.jpg', size: '110 KB' },
          { name: 'Categories (1080x1920)', file: 'phone-3-categories.jpg', size: '25 KB' }
        ]
      },
      {
        category: '7-inch Tablet',
        icon: Tablet,
        items: [
          { name: 'Homepage (1920x1200)', file: 'tablet-7inch-1-homepage.jpg', size: '82 KB' },
          { name: 'Browse (1920x1200)', file: 'tablet-7inch-2-browse.jpg', size: '95 KB' }
        ]
      },
      {
        category: '10-inch Tablet',
        icon: Tablet,
        items: [
          { name: 'Homepage (2560x1600)', file: 'tablet-10inch-1-homepage.jpg', size: '103 KB' },
          { name: 'Browse (2560x1600)', file: 'tablet-10inch-2-browse.jpg', size: '138 KB' }
        ]
      }
    ]
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert('Kopyalandı! ✅');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            📦 Play Store Materyalleri
          </h1>
          <p className="text-gray-600 mb-6">
            Relivv Marktplaats için tüm gerekli dosyalar
          </p>

          {/* Download All Button */}
          <a
            href="/play-store-complete-package.zip"
            download
            className="inline-flex items-center gap-2 px-8 py-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-lg font-semibold shadow-lg"
          >
            <Download className="w-6 h-6" />
            Tümünü İndir (ZIP - 622 KB)
          </a>
        </div>

        {/* Texts Section */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
            <FileText className="w-6 h-6 text-blue-600" />
            Metinler
          </h2>

          {assets.texts.map((text, idx) => (
            <div key={idx} className="mb-6 pb-6 border-b last:border-b-0">
              <h3 className="font-semibold text-gray-900 mb-2">{text.title}</h3>
              {text.content && (
                <>
                  <div className="bg-gray-50 p-4 rounded-lg mb-2 max-h-96 overflow-y-auto">
                    <p className="text-gray-700 whitespace-pre-wrap text-sm">{text.content}</p>
                  </div>
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                    <span className="text-sm text-gray-500">{text.chars} karakter</span>
                    <button
                      onClick={() => copyToClipboard(text.content)}
                      className="px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors text-sm font-medium"
                    >
                      📋 Kopyala
                    </button>
                  </div>
                </>
              )}
              {text.note && (
                <p className="text-sm text-gray-600 italic">{text.note}</p>
              )}
            </div>
          ))}
        </div>

        {/* Images Section */}
        {assets.images.map((category, idx) => {
          const IconComponent = category.icon;
          return (
            <div key={idx} className="bg-white rounded-lg shadow-lg p-6 mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <IconComponent className="w-6 h-6 text-blue-600" />
                {category.category}
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {category.items.map((item, itemIdx) => (
                  <div key={itemIdx} className="border border-gray-200 rounded-lg p-4 hover:border-blue-500 transition-colors">
                    <div className="mb-3">
                      <img
                        src={`/play-store-assets/${item.file}`}
                        alt={item.name}
                        className="w-full h-32 object-contain bg-gray-50 rounded"
                      />
                    </div>
                    <h3 className="font-semibold text-gray-900 text-sm mb-1">{item.name}</h3>
                    <p className="text-xs text-gray-500 mb-3">{item.size}</p>
                    <a
                      href={`/play-store-assets/${item.file}`}
                      download
                      className="flex items-center justify-center gap-2 w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                    >
                      <Download className="w-4 h-4" />
                      İndir
                    </a>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {/* URLs Section */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            🔗 URL'ler
          </h2>

          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Gizlilik Politikası</h3>
              <div className="bg-gray-50 p-3 rounded-lg mb-2">
                <code className="text-sm text-gray-700">
                  https://relivv-marketplace-1.preview.emergentagent.com/privacy-policy
                </code>
              </div>
              <button
                onClick={() => copyToClipboard('https://relivv-marketplace-1.preview.emergentagent.com/privacy-policy')}
                className="px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors text-sm font-medium"
              >
                📋 Kopyala
              </button>
            </div>

            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Hesap Silme</h3>
              <div className="bg-gray-50 p-3 rounded-lg mb-2">
                <code className="text-sm text-gray-700">
                  https://relivv-marketplace-1.preview.emergentagent.com/delete-account
                </code>
              </div>
              <button
                onClick={() => copyToClipboard('https://relivv-marketplace-1.preview.emergentagent.com/delete-account')}
                className="px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors text-sm font-medium"
              >
                📋 Kopyala
              </button>
            </div>

            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Destek Email</h3>
              <div className="bg-gray-50 p-3 rounded-lg mb-2">
                <code className="text-sm text-gray-700">
                  support@relivv.nl
                </code>
              </div>
              <button
                onClick={() => copyToClipboard('support@relivv.nl')}
                className="px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors text-sm font-medium"
              >
                📋 Kopyala
              </button>
            </div>
          </div>
        </div>

        {/* Info Box */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="font-semibold text-blue-900 mb-2">📱 Mobil İpucu</h3>
          <p className="text-sm text-blue-800">
            Dosyaları tek tek indirin veya üstteki "Tümünü İndir" butonuyla ZIP olarak alın. 
            ZIP dosyasını açmak için telefonunuzda bir dosya yöneticisi uygulaması gerekebilir.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PlayStoreAssets;
