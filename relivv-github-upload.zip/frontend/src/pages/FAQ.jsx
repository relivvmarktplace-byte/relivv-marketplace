import React from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';

const FAQ = () => {
  const { t } = useTranslation();

  const faqs = [
    {
      category: t('faq.general', { defaultValue: 'General' }),
      questions: [
        {
          q: t('faq.q1', { defaultValue: 'What is Relivv?' }),
          a: t('faq.a1', { defaultValue: 'Relivv is a sustainable second-hand marketplace in the Netherlands where you can buy and sell pre-loved items securely with escrow payment protection.' })
        },
        {
          q: t('faq.q2', { defaultValue: 'How does Relivv work?' }),
          a: t('faq.a2', { defaultValue: 'Simply create an account, list your items with photos and descriptions, or browse and purchase from other sellers. We handle secure payments through escrow.' })
        },
        {
          q: t('faq.q3', { defaultValue: 'Is Relivv free to use?' }),
          a: t('faq.a3', { defaultValue: 'Creating an account and browsing is free. We charge a 5% commission only on successful sales.' })
        }
      ]
    },
    {
      category: t('faq.selling', { defaultValue: 'Selling' }),
      questions: [
        {
          q: t('faq.q4', { defaultValue: 'How do I list a product?' }),
          a: t('faq.a4', { defaultValue: 'Click "Sell" in the menu, fill in the product details, upload photos, set your location, and publish. It\'s that simple!' })
        },
        {
          q: t('faq.q5', { defaultValue: 'What is the commission fee?' }),
          a: t('faq.a5', { defaultValue: 'We charge 5% commission on successful sales. This covers payment processing, buyer protection, and platform maintenance.' })
        },
        {
          q: t('faq.q6', { defaultValue: 'When do I receive payment?' }),
          a: t('faq.a6', { defaultValue: 'Payments are held in escrow and released to you 3 days after the buyer confirms delivery, ensuring secure transactions.' })
        }
      ]
    },
    {
      category: t('faq.buying', { defaultValue: 'Buying' }),
      questions: [
        {
          q: t('faq.q7', { defaultValue: 'How do I purchase an item?' }),
          a: t('faq.a7', { defaultValue: 'Browse products, click "Buy Now" on any item, and complete the secure checkout with Stripe. Your payment is held in escrow until delivery.' })
        },
        {
          q: t('faq.q8', { defaultValue: 'Is my payment secure?' }),
          a: t('faq.a8', { defaultValue: 'Yes! We use Stripe for payment processing and escrow protection. Your money is only released to the seller after you confirm delivery.' })
        },
        {
          q: t('faq.q9', { defaultValue: 'Can I get a refund?' }),
          a: t('faq.a9', { defaultValue: 'Yes, you can cancel the transaction and receive a full refund before confirming delivery. Contact support if you have any issues.' })
        }
      ]
    },
    {
      category: t('faq.safety', { defaultValue: 'Safety & Security' }),
      questions: [
        {
          q: t('faq.q10', { defaultValue: 'How is Relivv safe?' }),
          a: t('faq.a10', { defaultValue: 'We use escrow payments, verified profiles, seller ratings, and secure Stripe payment processing to ensure safe transactions.' })
        },
        {
          q: t('faq.q11', { defaultValue: 'What if I have a problem with a seller?' }),
          a: t('faq.a11', { defaultValue: 'Contact our support team immediately. We can help mediate disputes and, if necessary, issue refunds through our escrow system.' })
        }
      ]
    },
    {
      category: t('faq.account', { defaultValue: 'Account & Support' }),
      questions: [
        {
          q: t('faq.q12', { defaultValue: 'How do I update my profile?' }),
          a: t('faq.a12', { defaultValue: 'Go to your account dashboard by clicking your name in the header, then select the "Profile" tab to update your information.' })
        },
        {
          q: t('faq.q13', { defaultValue: 'How can I contact support?' }),
          a: t('faq.a13', { defaultValue: 'Email us at support@relivv.nl or use the contact form in the footer. We typically respond within 24 hours.' })
        },
        {
          q: t('faq.q14', { defaultValue: 'Can I delete my account?' }),
          a: t('faq.a14', { defaultValue: 'Yes, go to Settings in your dashboard and select "Delete Account". Note that this action is irreversible.' })
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 pt-24 pb-12">
      <div className="container mx-auto px-6 max-w-4xl">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-slate-800 mb-4">
            ❓ {t('faq.title', { defaultValue: 'Frequently Asked Questions' })}
          </h1>
          <p className="text-slate-600 text-xl">
            {t('faq.subtitle', { defaultValue: 'Find answers to common questions about Relivv' })}
          </p>
        </div>

        <div className="space-y-8">
          {faqs.map((section, idx) => (
            <div key={idx}>
              <h2 className="text-2xl font-bold text-slate-800 mb-4">{section.category}</h2>
              <div className="space-y-4">
                {section.questions.map((faq, qIdx) => (
                  <Card key={qIdx} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                    <CardHeader>
                      <CardTitle className="text-lg text-indigo-600">{faq.q}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-slate-600 leading-relaxed">{faq.a}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Card className="border-0 shadow-xl bg-gradient-to-r from-indigo-500 to-purple-500 text-white">
            <CardContent className="py-12">
              <h3 className="text-2xl font-bold mb-4">
                {t('faq.stillNeedHelp', { defaultValue: 'Still need help?' })}
              </h3>
              <p className="mb-6 text-lg">
                {t('faq.contactUs', { defaultValue: 'Our support team is here to assist you' })}
              </p>
              <a 
                href="mailto:support@relivv.nl"
                className="inline-block bg-white text-indigo-600 font-semibold px-8 py-3 rounded-xl hover:bg-slate-50 transition-colors"
              >
                📧 {t('faq.emailSupport', { defaultValue: 'Email Support' })}
              </a>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default FAQ;
