import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import axios from 'axios';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const Dashboard = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('profile');
  const [user, setUser] = useState(null);
  const [myProducts, setMyProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [profileData, setProfileData] = useState({
    name: '',
    email: '',
    phone: ''
  });

  useEffect(() => {
    fetchUserData();
    fetchMyProducts();
  }, []);

  const fetchUserData = async () => {
    try {
      const userData = JSON.parse(localStorage.getItem('user') || '{}');
      setUser(userData);
      setProfileData({
        name: userData.name || '',
        email: userData.email || '',
        phone: userData.phone || ''
      });
    } catch (error) {
      console.error('Error fetching user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchMyProducts = async () => {
    try {
      const response = await axios.get(`${API}/users/me/products`);
      setMyProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const handleProfileUpdate = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.put(`${API}/users/me`, profileData);
      localStorage.setItem('user', JSON.stringify(response.data));
      setUser(response.data);
      toast.success(t('dashboard.profileUpdated', { defaultValue: 'Profile updated successfully!' }));
    } catch (error) {
      toast.error(t('dashboard.profileUpdateFailed', { defaultValue: 'Failed to update profile' }));
    }
  };

  const handleDeleteProduct = async (productId) => {
    if (!window.confirm(t('dashboard.confirmDelete', { defaultValue: 'Are you sure you want to delete this product?' }))) {
      return;
    }
    try {
      await axios.delete(`${API}/products/${productId}`);
      setMyProducts(myProducts.filter(p => p.id !== productId));
      toast.success(t('dashboard.productDeleted', { defaultValue: 'Product deleted successfully!' }));
    } catch (error) {
      toast.error(t('dashboard.deleteFailed', { defaultValue: 'Failed to delete product' }));
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-indigo-50">
        <div className="animate-spin rounded-full h-16 w-16 border-4 border-indigo-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 pt-24 pb-12">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-slate-800 mb-2">
            👤 {t('dashboard.title', { defaultValue: 'My Account' })}
          </h1>
          <p className="text-sm sm:text-base text-slate-600">
            {t('dashboard.subtitle', { defaultValue: 'Manage your account and products' })}
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="mb-8 bg-white rounded-xl p-2 shadow-lg overflow-x-auto">
            <TabsList className="inline-flex min-w-full md:w-full md:grid md:grid-cols-7 gap-2 bg-transparent">
              <TabsTrigger value="profile" className="rounded-lg whitespace-nowrap flex-shrink-0 min-w-fit px-4">
                <span className="hidden sm:inline">👤 </span>{t('dashboard.profile', { defaultValue: 'Profile' })}
              </TabsTrigger>
              <TabsTrigger value="products" className="rounded-lg whitespace-nowrap flex-shrink-0 min-w-fit px-4">
                <span className="hidden sm:inline">📦 </span>{t('dashboard.myProducts', { defaultValue: 'Products' })}
              </TabsTrigger>
              <TabsTrigger value="sales" className="rounded-lg whitespace-nowrap flex-shrink-0 min-w-fit px-4">
                <span className="hidden sm:inline">💰 </span>{t('dashboard.mySales', { defaultValue: 'Sales' })}
              </TabsTrigger>
              <TabsTrigger value="orders" className="rounded-lg whitespace-nowrap flex-shrink-0 min-w-fit px-4" onClick={() => navigate('/orders')}>
                <span className="hidden sm:inline">🛒 </span>{t('dashboard.myOrders', { defaultValue: 'Orders' })}
              </TabsTrigger>
              <TabsTrigger value="favorites" className="rounded-lg whitespace-nowrap flex-shrink-0 min-w-fit px-4">
                <span className="hidden sm:inline">❤️ </span>{t('dashboard.favorites', { defaultValue: 'Favorites' })}
              </TabsTrigger>
              <TabsTrigger value="messages" className="rounded-lg whitespace-nowrap flex-shrink-0 min-w-fit px-4">
                <span className="hidden sm:inline">💬 </span>{t('dashboard.messages', { defaultValue: 'Messages' })}
              </TabsTrigger>
              <TabsTrigger value="settings" className="rounded-lg whitespace-nowrap flex-shrink-0 min-w-fit px-4">
                <span className="hidden sm:inline">⚙️ </span>{t('dashboard.settings', { defaultValue: 'Settings' })}
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card className="border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl">
                  {t('dashboard.profileInfo', { defaultValue: 'Profile Information' })}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleProfileUpdate} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      {t('auth.name')}
                    </label>
                    <Input
                      type="text"
                      value={profileData.name}
                      onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                      className="rounded-xl h-12"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      {t('auth.email')}
                    </label>
                    <Input
                      type="email"
                      value={profileData.email}
                      onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                      className="rounded-xl h-12"
                      required
                      disabled
                    />
                    <p className="text-xs text-slate-500 mt-1">
                      {t('dashboard.emailCannotChange', { defaultValue: 'Email cannot be changed' })}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      {t('auth.phone')}
                    </label>
                    <PhoneInput
                      country={'nl'}
                      value={profileData.phone}
                      onChange={(phone) => setProfileData({ ...profileData, phone: phone })}
                      inputProps={{
                        name: 'phone',
                        required: false
                      }}
                      containerStyle={{
                        width: '100%'
                      }}
                      inputStyle={{
                        width: '100%',
                        height: '48px',
                        borderRadius: '12px',
                        border: '1px solid #e2e8f0',
                        fontSize: '16px',
                        paddingLeft: '48px'
                      }}
                      buttonStyle={{
                        borderRadius: '12px 0 0 12px',
                        border: '1px solid #e2e8f0',
                        backgroundColor: '#f8fafc'
                      }}
                      dropdownStyle={{
                        borderRadius: '12px',
                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                      }}
                      enableSearch={true}
                      searchPlaceholder={t('auth.searchCountry', { defaultValue: 'Search country...' })}
                      preferredCountries={['nl', 'be', 'de', 'fr', 'gb']}
                    />
                  </div>
                  {user?.is_business_seller && (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">
                          {t('dashboard.businessName', { defaultValue: 'Business Name' })}
                        </label>
                        <Input
                          type="text"
                          value={user.business_name || ''}
                          disabled
                          className="rounded-xl h-12 bg-slate-50"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">
                          {t('dashboard.vatNumber', { defaultValue: 'VAT Number' })}
                        </label>
                        <Input
                          type="text"
                          value={user.vat_number || ''}
                          disabled
                          className="rounded-xl h-12 bg-slate-50"
                        />
                      </div>
                    </>
                  )}
                  <Button 
                    type="submit"
                    className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white rounded-xl"
                  >
                    {t('dashboard.saveChanges', { defaultValue: 'Save Changes' })}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* My Products Tab */}
          <TabsContent value="products">
            <Card className="border-0 shadow-xl">
              <CardHeader>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <CardTitle className="text-xl sm:text-2xl">
                    {t('dashboard.myProducts', { defaultValue: 'My Products' })}
                  </CardTitle>
                  <Button 
                    onClick={() => navigate('/sell')}
                    className="w-full sm:w-auto bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white rounded-xl text-sm sm:text-base"
                  >
                    ➕ {t('dashboard.addNewProduct', { defaultValue: 'Add New Product' })}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {myProducts.length === 0 ? (
                  <div className="text-center py-12">
                    <div className="w-24 h-24 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <span className="text-4xl">📦</span>
                    </div>
                    <p className="text-slate-600 text-xl mb-4">
                      {t('dashboard.noProducts', { defaultValue: 'You have not listed any products yet' })}
                    </p>
                    <Button 
                      onClick={() => navigate('/sell')}
                      className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-xl"
                    >
                      {t('dashboard.listFirstProduct', { defaultValue: 'List Your First Product' })}
                    </Button>
                  </div>
                ) : (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {myProducts.map(product => (
                      <Card key={product.id} className="overflow-hidden">
                        <img 
                          src={product.images[0] || '/placeholder.jpg'} 
                          alt={product.title}
                          className="w-full h-48 object-cover"
                        />
                        <CardContent className="p-4">
                          <h3 className="font-bold text-base sm:text-lg mb-2 line-clamp-2">{product.title}</h3>
                          <p className="text-emerald-600 font-bold text-lg sm:text-xl mb-3">€{product.price}</p>
                          <div className="flex flex-col sm:flex-row gap-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => navigate(`/edit-product/${product.id}`)}
                              className="flex-1 text-sm"
                            >
                              ✏️ {t('common.edit')}
                            </Button>
                            <Button 
                              variant="destructive" 
                              size="sm"
                              onClick={() => handleDeleteProduct(product.id)}
                              className="flex-1 text-sm"
                            >
                              🗑️ {t('common.delete')}
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Other tabs - Coming Soon */}
          <TabsContent value="sales">
            <Card className="border-0 shadow-xl">
              <CardContent className="py-12 text-center">
                <div className="w-24 h-24 bg-gradient-to-br from-emerald-100 to-teal-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-4xl">💰</span>
                </div>
                <h3 className="text-2xl font-bold text-slate-800 mb-4">
                  {t('dashboard.salesComingSoon', { defaultValue: 'Sales History Coming Soon' })}
                </h3>
                <p className="text-slate-600">
                  {t('dashboard.salesDesc', { defaultValue: 'Track your sales and earnings here' })}
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="favorites">
            <Card className="border-0 shadow-xl">
              <CardContent className="py-12 text-center">
                <div className="w-24 h-24 bg-gradient-to-br from-pink-100 to-rose-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-4xl">❤️</span>
                </div>
                <h3 className="text-2xl font-bold text-slate-800 mb-4">
                  {t('dashboard.favoritesComingSoon', { defaultValue: 'Favorites Coming Soon' })}
                </h3>
                <p className="text-slate-600">
                  {t('dashboard.favoritesDesc', { defaultValue: 'Save your favorite products here' })}
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="messages">
            <Card className="border-0 shadow-xl">
              <CardContent className="py-12 text-center">
                <div className="w-24 h-24 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-4xl">💬</span>
                </div>
                <h3 className="text-2xl font-bold text-slate-800 mb-4">
                  {t('dashboard.messagesComingSoon', { defaultValue: 'Messages Coming Soon' })}
                </h3>
                <p className="text-slate-600">
                  {t('dashboard.messagesDesc', { defaultValue: 'Chat with buyers and sellers here' })}
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card className="border-0 shadow-xl">
              <CardContent className="py-12 text-center">
                <div className="w-24 h-24 bg-gradient-to-br from-slate-100 to-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-4xl">⚙️</span>
                </div>
                <h3 className="text-2xl font-bold text-slate-800 mb-4">
                  {t('dashboard.settingsComingSoon', { defaultValue: 'Settings Coming Soon' })}
                </h3>
                <p className="text-slate-600">
                  {t('dashboard.settingsDesc', { defaultValue: 'Manage your account settings here' })}
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Dashboard;
